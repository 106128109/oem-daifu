-- MySQL dump 10.13  Distrib 5.6.50, for Linux (x86_64)
--
-- Host: localhost    Database: daifu_fk08_cn
-- ------------------------------------------------------
-- Server version	5.6.50-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pay_admin`
--

DROP TABLE IF EXISTS `pay_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_admin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `username` varchar(50) NOT NULL COMMENT '后台用户名',
  `password` varchar(32) NOT NULL COMMENT '后台用户密码',
  `groupid` tinyint(1) unsigned DEFAULT '0' COMMENT '用户组',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `google_secret_key` varchar(128) NOT NULL DEFAULT '' COMMENT '谷歌令牌密钥',
  `mobile` varchar(255) NOT NULL DEFAULT '' COMMENT '手机号码',
  `session_random` varchar(50) NOT NULL DEFAULT '' COMMENT 'session随机字符串',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=508 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_admin`
--

LOCK TABLES `pay_admin` WRITE;
/*!40000 ALTER TABLE `pay_admin` DISABLE KEYS */;
INSERT INTO `pay_admin` VALUES (505,'taoke','84f3703818729f3f8be493d8c9c8f037',1,1567404693,'TA3YEFYVW4QZORI6','','LgVVwKRlDWWfCbmgYKkLgpk8yakgEBat');
/*!40000 ALTER TABLE `pay_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_apimoney`
--

DROP TABLE IF EXISTS `pay_apimoney`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_apimoney` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `payapiid` int(11) DEFAULT NULL,
  `money` decimal(15,2) NOT NULL DEFAULT '0.00',
  `freezemoney` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '冻结金额',
  `status` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_apimoney`
--

LOCK TABLES `pay_apimoney` WRITE;
/*!40000 ALTER TABLE `pay_apimoney` DISABLE KEYS */;
INSERT INTO `pay_apimoney` VALUES (10,6,207,18000.00,0.00,1);
/*!40000 ALTER TABLE `pay_apimoney` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_article`
--

DROP TABLE IF EXISTS `pay_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `groupid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '分组  0：所有 1：商户 2：代理',
  `title` varchar(300) NOT NULL COMMENT '标题',
  `content` text COMMENT '内容',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1显示 0 不显示',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_article`
--

LOCK TABLES `pay_article` WRITE;
/*!40000 ALTER TABLE `pay_article` DISABLE KEYS */;
INSERT INTO `pay_article` VALUES (16,3,0,'客户告知书','<p></p><p>尊敬的商户朋友：  </p><p>           <br /></p><p>    本公司是一家正规的网络公司，是各大游戏充值卡发卡商，电商平台等中小型企业长期的合作伙伴；</p><p><br /></p><p>      本公司郑重告知，请各客户加强业务自审勿与违法违规的业务发生关联，比如涉黄、涉赌、涉及网络诈骗等；我公司一经发现有涉及违法违规的业务，我公司将把相关信息上报公安机关派驻我公司的网安警务室处理。        </p><p><br /></p><p style=\"text-align:right;\">请合作的客户知晓并认真审查业务 特此告知！  </p><p><br /></p><p style=\"text-align:right;\">2018/1/11 8:18:18</p>',1515717667,'',1,1563744064),(17,3,0,'收银台 商户收款码 使用说明','<p>如 商户收款码页面报错 请在</p><p>PHP 扩展里安装以下扩展</p><p><span>fileinfo</span></p><p><span>imagemagick</span></p>',1534324869,'系统升级公告',1,1563662418),(18,0,0,'20190721版本更新说明','<p><b>更新时间：20190721</b></p><p>前台安全机制增加 双重验证：短信和谷歌验证 可以自主选择验证方式</p><p>修正提现时间，现在可以在提现设置里自主选择任意时间。</p><p>增加系统设置栏目各个功能 需短信验证或谷歌验证。</p><p>修复后台数据清理 部分数据无法清理BUG。</p><p>优化订单金额小数点<span>限制为两位数</span>。</p><p>修改提现提醒方式 现在只在后台首页提示。</p><p><br /></p><p><b>更新时间：20190619</b></p><p>增加虚拟订单功能</p><p>修复平台LOGO无法上传BUG</p><p><b>更新时间：20190616</b></p><p>修复开启ssl后谷歌安全二维码无法显示BUG</p><p><b>更新时间：20190531</b></p><p>修复更改前台、后台路径后， 无法正常登陆bug</p><p>增加自动记录：下游上送数据，上游回调信息，无需在接口中改动。</p><p><b>更新时间：20190501</b></p><p>修复 <span>AJAX</span>跨域<span>攻击（重要！！！）</span></p><p><span>（可导致代付订单信息被篡改）</span></p><p><b>2019-04-20 </b><strong>v6.0 </strong></p><p><b>修复XSS攻击漏洞</b></p><p><b>修复前后台getshell漏洞</b></p><p><b>修复点击劫持漏洞</b></p><p><b>2019-03-26 </b><strong>v6.0 </strong></p><p>谷歌身份验证器无法使用BUG</p><p>已修复！前台后台均可正常验证</p><p>更加安全稳定！</p><p><b>2019-03-20 v6.0 （重大BUG）</b></p><p>后台管理权限账号 可提权获取服务器控制权</p><p>已修复！</p><p><b>2019-03-10 v6.0</b></p><p>修复不同权限后台登录提示 无权限BUG</p><p><b>2019-03-19 v6.0</b></p><p>更新商户中心 API帮助文档</p><p><b>2019-03-13 v6.0</b></p><p>更新商户中心UI 自适应手机浏览</p><p><br /></p><p>2019-03-10 <strong>v6.0</strong></p><p>更新前台模板一套 包含首页 注册页 登录页</p><p><br /></p>2019-02-17 <strong>v6.0</strong>修复结算方式为T0前台不显示费率修复后台设置运营费率不及时刷新<p>修复几处细节问题</p><p><br /></p>2018-12-05 <strong>v6.0</strong>修复单独设置商户提现规则<p>开启个人规则后无法关闭问题</p><p>修复几处细节问题</p>2018-11-24 <strong>v6.0</strong>修复单通道查询统计显示负数修复通道费率修改后不及时刷新<p>修复GOOGLE谷歌令牌验证几处BUG</p><p><br /></p>2018-11-18 <strong>v6.0</strong>优化完善商户中心 后台移动设备操作修复后台无法 冻结订单、解冻订单修复 导出xls文件乱码修复 统计、结算金额显示bug修复 缓存模块bug修复 商户提现无法输出json的bug<p>修复 阿里云短信模块</p><p><br /></p><p>2018-11-03 <strong>v5.8</strong></p>更新 账号轮询功能优化更新 管理后台根据用户结算周期类型结算更新 代付扩展字段添加BUG<p>增加 官方支付宝、微信、QQ钱包 对接接口</p><p><br /></p>2018-11-03 <strong>v5.6</strong>开放商户充值链接 可在后台选择开启或关闭更新 商户中心管理通道费率显示BUG优化商户管理UI 自适应手机操作修复 通道删除时的bug<p>修复 清理登录日志的bug</p><p><br /></p>2018-10-30 <strong>v5.6</strong>增加批量删除订单功能增加后台切换模板功能修复入金通道列表 费率显示BUG增加 检测http[s]网址头增加 后台订单分析/通道分析/代理分析/<p>修复 代理下级商户页面 翻页的bug</p><p><br /></p>2018-10-25 <strong>v5.6</strong>商户中心UI自适应全部移动设备，各类操作均可以在PC和移动设备上完成优化订单导出BUG，导出XLS 显示通道类别 不再显示 入金通道详细名称修复高级代理无法添加中级 普通代理BUG修复 某些页面自适应的bug更新 常用接口，易于修改和测试<p><br /></p><p><br /></p><p>功能新增列表：</p><p>1.异常订单显示，程序自动补发订单后的订单列表（无法自动补发的 可以在异常订单里快速查询到）</p><p>2. 手动订单系统（上游无补单API将无法使用该功能）</p><p>3. 模板管理（后台切换前台模板 共6套模板可供选择）</p><p>4. 用户分类修改添加管理</p><p>5. 在线升级（建议屏蔽 官方升级会自动锁定非法商业用户）</p><p>6. 版权所有（鸡肋，不用可以注释掉）</p><p>7.修复商户提现 后台提现通知语音提示</p><p>8.修复商户提现（阿里云短信API） 可定制不同的短信模板</p><p>9.修复商户代付API，已封堵SQL注入！</p><p>10.优化商户、代理中心、后台 所有UI 自适应手机访问和操作</p>',1539144000,'',1,1563743981),(19,0,0,'系统说明','<p>第四方支付 大数据版 API支付系统 支持轮询 代付API 全开源</p><p>系统的注意安装事项</p><p>1.Nginx 推荐 Tengine2.2.4(2.3.0)</p><p>2.MySQL 5.5</p><p>3.php 7.0+</p><p>4.宝塔控制台</p><p>自带8套模板 可在后台随意切换</p><p>自带已调试过的 上游API接口代码 100多个 免除您对接之忧。</p><p>以下支付平台接口均已测试  </p><p>可免费提供客户使用！</p><p>kuaikuaifu pop支付 Qpay</p><p>QQ钱包官方 微信支付官方 支付宝官方 </p><p>unpay 宝付 畅付云 新豆豆 多来米 </p><p>国付 国付宝   国通支付  国银合众 </p><p>虎付  环迅   汇达  汇通  九派  聚合融通 </p><p>开心支付  科软云  支付乐  百付  立刻支付  立客支付 </p><p>领胜支付  免签对接  免签约助手 </p><p>摩宝  蘑菇支付 浦发银行  </p><p>前海亿联 轻易付 如意金服 睿付快捷 睿付扫码 </p><p>扫呗支付  杉德  闪豆 商银信 生活圈 时时支付 </p><p>速汇付 随行付 天付宝 威富通 新希望  信付宝 </p><p>易宝 易畅付  易通银  聚优  畅优云</p><p>掌炅  智付  智能云   爰农支付 更多接口 持续整理中</p>',1540469492,'',1,1563661614);
/*!40000 ALTER TABLE `pay_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_attachment`
--

DROP TABLE IF EXISTS `pay_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_attachment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '商户编号',
  `filename` varchar(100) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_attachment`
--

LOCK TABLES `pay_attachment` WRITE;
/*!40000 ALTER TABLE `pay_attachment` DISABLE KEYS */;
INSERT INTO `pay_attachment` VALUES (83,5,'5d41cb255f2f9.png','Uploads/verifyinfo/5d41dcfed374b.png'),(82,5,'59afc4b290cbb.jpg','Uploads/verifyinfo/5d41dcfecdedc.jpg'),(81,5,'5d41c29a20a7a.jpg','Uploads/verifyinfo/5d41dcfec2d3b.jpg'),(80,5,'59b1ffd5a19ae.jpg','Uploads/verifyinfo/5d41db4a3db6a.jpg'),(79,5,'59afc5d5ca2b1.jpg','Uploads/verifyinfo/5d41db4a24981.jpg'),(78,5,'5d41cb255f2f9.png','Uploads/verifyinfo/5d41db49c9c1f.png'),(77,5,'59b12b3e5cb5b.jpg','Uploads/verifyinfo/5d41db49c70b8.jpg'),(76,5,'59afc4b290cbb.jpg','Uploads/verifyinfo/5d41db49c44e8.jpg'),(75,5,'5d41c29a20a7a.jpg','Uploads/verifyinfo/5d41db49c158a.jpg'),(74,5,'5d41cb255f2f9.png','Uploads/verifyinfo/5d41db04cfaba.png'),(73,5,'5d41c29a20a7a.jpg','Uploads/verifyinfo/5d41db04cca60.jpg'),(72,5,'5d41c29a20a7a.jpg','Uploads/verifyinfo/5d41da523c6a5.jpg');
/*!40000 ALTER TABLE `pay_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_auth_error_log`
--

DROP TABLE IF EXISTS `pay_auth_error_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_auth_error_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `auth_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0：商户登录 1：后台登录 2：商户短信验证 3：后台短信验证 4：谷歌令牌验证 5：支付密码验证 ',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `ctime` int(11) NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_auth_error_log`
--

LOCK TABLES `pay_auth_error_log` WRITE;
/*!40000 ALTER TABLE `pay_auth_error_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_auth_error_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_auth_group`
--

DROP TABLE IF EXISTS `pay_auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `is_manager` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1需要验证权限 0 不需要验证权限',
  `rules` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_auth_group`
--

LOCK TABLES `pay_auth_group` WRITE;
/*!40000 ALTER TABLE `pay_auth_group` DISABLE KEYS */;
INSERT INTO `pay_auth_group` VALUES (1,'超级管理员',1,0,'1,133,2,3,51,4,57,5,55,56,58,59,6,44,52,53,48,70,54,7,8,60,61,62,9,63,64,65,66,10,67,68,69,11,12,79,80,81,82,83,84,85,86,87,88,89,90,91,93,94,95,96,97,98,99,100,101,120,13,14,15,92,16,73,76,77,78,17,46,121,18,19,71,75,20,72,74,22,21,23,114,115,24,25,26,125,127,130,134,27,28,108,129,29,102,30,103,106,107,119,104,105,109,110,111,128,31,32,33,34,35,36,37,38,39,113,40,112,41,42,45,47,116,122,117,123,118,124,137,138'),(2,'运营管理员',1,0,'1,133,3,51,4,57,5,55,56,59,6,44,52,70,54,12,79,80,81,82,83,84,85,86,87,93,94,98,99,13,14,15,92,73,76,77,78,46,18,19,71,22,23,24,33,34,35,36,37,38,39,113,40,112,41,42,45,47'),(3,'财务管理员',1,1,'1,133,27,29,102'),(4,'普通商户',1,1,'22,24'),(5,'普通代理商',2,1,'114,115');
/*!40000 ALTER TABLE `pay_auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_auth_group_access`
--

DROP TABLE IF EXISTS `pay_auth_group_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_auth_group_access`
--

LOCK TABLES `pay_auth_group_access` WRITE;
/*!40000 ALTER TABLE `pay_auth_group_access` DISABLE KEYS */;
INSERT INTO `pay_auth_group_access` VALUES (1,1),(2,1),(3,2),(504,1),(505,1);
/*!40000 ALTER TABLE `pay_auth_group_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_auth_rule`
--

DROP TABLE IF EXISTS `pay_auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `icon` varchar(100) DEFAULT '' COMMENT '图标',
  `menu_name` varchar(100) NOT NULL DEFAULT '' COMMENT '规则唯一标识Controller/action',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `pid` tinyint(5) NOT NULL DEFAULT '0' COMMENT '菜单ID ',
  `is_menu` tinyint(1) unsigned DEFAULT '0' COMMENT '1:是主菜单 0否',
  `is_race_menu` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1:是 0:不是',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `condition` char(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=139 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_auth_rule`
--

LOCK TABLES `pay_auth_rule` WRITE;
/*!40000 ALTER TABLE `pay_auth_rule` DISABLE KEYS */;
INSERT INTO `pay_auth_rule` VALUES (1,'fa fa-home','Index/index','管理首页',0,1,0,1,1,''),(2,'fa fa-cogs','System/#','系统设置',0,1,0,1,1,''),(3,'fa fa-cogs','System/base','基本设置',2,1,0,1,1,''),(4,'fa fa-envelope-o','System/email','邮件设置',2,1,0,1,1,''),(5,'fa fa-send','System/smssz','短信设置',2,1,0,1,1,''),(6,'fa fa-pencil-square-o','System/planning','计划任务',2,1,0,1,1,''),(7,'fa fa-user-circle','Admin/#','管理员管理',0,1,0,1,1,''),(8,'fa fa-vcard ','Admin/index','管理员信息',7,1,0,1,1,''),(9,'fa fa-life-ring','Auth/index','角色配置',7,1,0,1,1,''),(10,'fa fa-universal-access','Menu/index','权限配置',7,1,0,1,1,''),(11,'fa fa-users','User/#','用户管理',0,1,0,1,1,''),(12,'fa fa-user','User/index?status=1&authorized=1','已认证用户',11,1,0,1,1,''),(13,'fa fa-user-o','User/index?status=1&authorized=2','待认证用户',11,1,0,1,1,''),(14,'fa fa-user-plus','User/index?status=1&authorized=0','未认证用户',11,1,0,1,1,''),(15,'fa fa-user-times','User/index?status=0','冻结用户',11,1,0,1,1,''),(16,'fa fa-gift','User/invitecode','邀请码',11,1,0,1,1,''),(17,'fa fa-address-book','User/loginrecord','登录记录',11,1,0,1,1,''),(19,'fa fa-signing','User/agentList','代理列表',18,1,0,1,1,''),(20,'fa fa-signing','Order/changeRecord?bank=9','佣金记录',18,1,0,1,1,''),(21,'fa fa-sellsy','Order/dfApiOrderList','代付Api订单',22,1,0,1,1,''),(22,'fa fa-reorder','User/#','代付订单管理',0,1,0,1,1,''),(23,'fa fa-indent','Order/changeRecord','流水记录',22,1,0,1,1,''),(27,'fa fa-user-secret','Withdrawal','代付列表',0,1,0,1,1,''),(28,'fa fa-wrench','Withdrawal/setting','代付提款设置',2,1,0,1,1,''),(30,'fa fa-window-restore','Withdrawal/payment','代付结算',27,1,0,1,1,''),(34,'fa fa-sliders','PayForAnother/index','代付渠道设置',2,1,0,1,1,''),(38,'fa fa-line-chart','Statistics/#','财务分析',0,1,0,1,1,''),(43,'fa fa-cubes','Template/index','模板设置',2,1,0,1,0,''),(44,'fa fa-qq','System/mobile','手机设置',2,1,0,1,1,''),(48,'fa fa-magnet','System/clearData','数据清理',2,1,0,1,1,''),(51,'','System/SaveBase','保存设置',3,0,0,1,1,''),(52,'','System/BindMobileShow','绑定手机号码',44,0,0,1,1,''),(53,'','System/editMobileShow','手机修改',44,0,0,1,1,''),(54,'fa fa-wrench','System/editPassword','修改密码',2,1,0,1,1,''),(55,'','System/editSmstemplate','短信模板',5,0,0,1,1,''),(56,'','System/saveSmstemplate','保存短信模板',5,0,0,1,1,''),(57,'','System/saveEmail','邮件保存',4,0,0,1,1,''),(58,'','System/testMobile','测试短信',5,0,0,1,1,''),(59,'','System/deleteAdmin','删除短信模板',5,0,0,1,1,''),(60,'','Admin/addAdmin','管理员添加',8,0,0,1,1,''),(61,'','Admin/editAdmin','管理员修改',8,0,0,1,1,''),(62,'','Admin/deleteAdmin','管理员删除',8,0,0,1,1,''),(63,'','Auth/addGroup','添加角色',9,0,0,1,1,''),(64,'','Auth/editGroup','修改角色',9,0,0,1,1,''),(65,'','Auth/giveRole','选择角色',9,0,0,1,1,''),(66,'','Auth/ruleGroup','分配权限',9,0,0,1,1,''),(67,'','Menu/addMenu','添加菜单',10,0,0,1,1,''),(68,'','Menu/editMenu','修改菜单',10,0,0,1,1,''),(69,'','Menu/delMenu','删除菜单',10,0,0,1,1,''),(70,'','System/clearDataSend','数据清理提交',48,0,0,1,1,''),(71,'','User/addAgentCate','代理级别',19,0,0,1,1,''),(72,'','User/saveAgentCate','保存代理级别',18,0,0,1,1,''),(73,'','User/addInvitecode','添加激活码',16,0,0,1,1,''),(74,'','User/EditAgentCate','修改代理分类',18,0,0,1,1,''),(75,'','User/deleteAgentCate','删除代理分类',19,0,0,1,1,''),(76,'','User/setInvite','邀请码设置',16,0,0,1,1,''),(77,'','User/addInvite','创建邀请码',16,0,0,1,1,''),(78,'','User/delInvitecode','删除邀请码',16,0,0,1,1,''),(79,'','User/editUser','用户编辑',12,0,0,1,1,''),(80,'','User/changeuser','修改状态',12,0,0,1,1,''),(81,'','User/authorize','用户认证',12,0,0,1,1,''),(82,'','User/usermoney','用户资金管理',12,0,0,1,1,''),(83,'','User/userWithdrawal','用户提现设置',12,0,0,1,1,''),(84,'','User/userRateEdit','用户费率设置',12,0,0,1,1,''),(85,'','User/editPassword','用户密码修改',12,0,0,1,1,''),(86,'','User/editStatus','用户状态修改',12,0,0,1,1,''),(87,'','User/delUser','用户删除',12,0,0,1,1,''),(88,'','User/thawingFunds','T1解冻任务管理',12,0,0,1,1,''),(89,'','User/exportuser','导出用户',12,0,0,1,1,''),(90,'','User/editAuthoize','修改用户认证',12,0,0,1,1,''),(91,'','User/getRandstr','切换商户密钥',12,0,0,1,1,''),(92,'','User/suoding','用户锁定',15,0,0,1,1,''),(93,'','User/editbankcard','银行卡管理',12,0,0,1,1,''),(94,'','User/saveUser','添加用户',12,0,0,1,1,''),(95,'','User/saveUserProduct','保存用户产品',12,0,0,1,1,''),(96,'','User/saveUserRate','保存用户费率',12,0,0,1,1,''),(97,'','User/edittongdao','编辑通道',12,0,0,1,1,''),(98,'','User/frozenMoney','用户资金冻结',12,0,0,1,1,''),(99,'','User/unfrozenHandles','T1资金解冻',12,0,0,1,1,''),(100,'','User/frozenOrder','冻结订单列表',12,0,0,1,1,''),(101,'','User/frozenHandles','T1订单解冻展示',12,0,0,1,1,''),(102,'','Withdrawal/editStatus','操作状态',29,0,0,1,1,''),(103,'','Withdrawal/editwtStatus','操作订单状态',30,0,0,1,1,''),(104,'','Withdrawal/exportorder','导出数据',27,0,0,1,1,''),(105,'','Withdrawal/editwtAllStatus','批量修改提款状态',27,0,0,1,1,''),(106,'','Withdrawal/exportweituo','导出委托提现',30,0,0,1,1,''),(107,'','Payment/index','提交上游',30,0,0,1,1,''),(108,'','Withdrawal/saveWithdrawal','保存设置',28,0,0,1,1,''),(109,'','Withdrawal/AddHoliday','添加假日',27,0,0,1,1,''),(110,'','Withdrawal/settimeEdit','编辑提款时间',27,0,0,1,1,''),(111,'','Withdrawal/delHoliday','删除节假日',27,0,0,1,1,''),(112,'','Statistics/exportorder','订单数据导出',40,0,0,1,1,''),(113,'','Statistics/details','查看详情',39,0,0,1,1,''),(114,'','Order/exportorder','订单导出',23,0,0,1,1,''),(115,'','Order/exceldownload','记录导出',23,0,0,1,1,''),(116,'fa fa-area-chart','Statistics/platformReport','平台报表',38,1,0,1,1,''),(117,'fa fa-area-chart','Statistics/merchantReport','商户报表',38,1,0,1,1,''),(118,'fa fa-area-chart','Statistics/agentReport','代理报表',38,1,0,1,1,''),(119,'','Withdrawal/submitDf','代付提交',30,0,0,1,1,''),(120,'','User/editUserProduct','分配用户通道',12,0,0,1,1,''),(122,'','Statistics/exportPlatform','导出平台报表',116,0,0,1,1,''),(123,'','Statistics/exportMerchant','导出商户报表',117,0,0,1,1,''),(124,'','Statistics/exportAgent','导出代理报表',118,0,0,1,1,''),(125,'','Order/show','查看订单',22,0,0,1,1,''),(126,'fa fa-cog','Withdrawal/checkNotice','提现申请声音提示',2,0,0,1,1,''),(128,'','Withdrawal/rejectAllDf','批量驳回代付',27,0,0,1,1,''),(129,'','User/saveWithdrawal','保存用户提款设置',28,0,0,1,1,''),(133,'fa fa-heartbeat','Index/main','后台首页',1,1,0,1,1,''),(137,'fa fa-asterisk','Statistics/userAnalysis','平台总报表',38,1,0,1,1,''),(138,'fa fa-asterisk','Statistics/frozenMoney','冻结资金分析',38,1,0,1,1,'');
/*!40000 ALTER TABLE `pay_auth_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_auto_df_log`
--

DROP TABLE IF EXISTS `pay_auto_df_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_auto_df_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `df_id` int(11) NOT NULL DEFAULT '0' COMMENT '代付ID',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型：1提交 2查询',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '结果 0：提交失败 1：提交成功 2：代付成功 3：代付失败',
  `msg` varchar(255) DEFAULT '' COMMENT '描述',
  `ctime` int(11) NOT NULL DEFAULT '0' COMMENT '提交时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_auto_df_log`
--

LOCK TABLES `pay_auto_df_log` WRITE;
/*!40000 ALTER TABLE `pay_auto_df_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_auto_df_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_auto_unfrozen_order`
--

DROP TABLE IF EXISTS `pay_auto_unfrozen_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_auto_unfrozen_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `freeze_money` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '冻结金额',
  `unfreeze_time` int(11) NOT NULL DEFAULT '0' COMMENT '计划解冻时间',
  `real_unfreeze_time` int(11) NOT NULL DEFAULT '0' COMMENT '实际解冻时间',
  `is_pause` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否暂停解冻 0正常解冻 1暂停解冻',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '解冻状态 0未解冻 1已解冻',
  `create_at` int(11) NOT NULL COMMENT '记录创建时间',
  `update_at` int(11) NOT NULL COMMENT '记录更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_unfreezeing` (`status`,`is_pause`,`unfreeze_time`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='投诉保证金余额';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_auto_unfrozen_order`
--

LOCK TABLES `pay_auto_unfrozen_order` WRITE;
/*!40000 ALTER TABLE `pay_auto_unfrozen_order` DISABLE KEYS */;
INSERT INTO `pay_auto_unfrozen_order` VALUES (1,180751041,89.00,0,0,0,0,1534428974,1534428974),(2,5,1000.00,1547111100,0,0,0,1547110860,1547110860);
/*!40000 ALTER TABLE `pay_auto_unfrozen_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_bankcard`
--

DROP TABLE IF EXISTS `pay_bankcard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_bankcard` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '商户编号',
  `bankname` varchar(100) NOT NULL COMMENT '银行名称',
  `subbranch` varchar(100) NOT NULL COMMENT '支行名称',
  `accountname` varchar(100) NOT NULL COMMENT '开户名',
  `cardnumber` varchar(100) NOT NULL COMMENT '银行卡号',
  `province` varchar(100) NOT NULL COMMENT '所属省',
  `city` varchar(100) NOT NULL COMMENT '所属市',
  `ip` varchar(100) DEFAULT NULL COMMENT '上次修改IP',
  `ipaddress` varchar(300) DEFAULT NULL COMMENT 'IP地址',
  `alias` varchar(255) DEFAULT '' COMMENT '备注',
  `isdefault` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否默认 1是 0 否',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `IND_UID` (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_bankcard`
--

LOCK TABLES `pay_bankcard` WRITE;
/*!40000 ALTER TABLE `pay_bankcard` DISABLE KEYS */;
INSERT INTO `pay_bankcard` VALUES (1,1,'中国工商银行','北京支行','测试','123456789','北京','北京',NULL,NULL,'测试',0,0),(2,3,'中国光大银行','光大银行天津南开支行','史增娜','6226632102952764','天津市','南开区',NULL,NULL,'',1,0),(3,3,'中国农业银行','德州支行','杨兰森','6228481819032303473','山东省','德州市',NULL,NULL,'',0,0),(4,3,'中国银行','天津吉利支行','刘绍东','6217850200015356414','天津市','和平区',NULL,NULL,'',0,0),(5,3,'中国农业银行','中国农业银行','杨兰森','6228481819032303473','山东省','德州市',NULL,NULL,'',0,0);
/*!40000 ALTER TABLE `pay_bankcard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_blockedlog`
--

DROP TABLE IF EXISTS `pay_blockedlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_blockedlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(100) NOT NULL COMMENT '订单号',
  `userid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '商户编号',
  `amount` decimal(15,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '冻结金额',
  `thawtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '解冻时间',
  `pid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '商户支付通道',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态 1 解冻 0 冻结',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='资金冻结待解冻记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_blockedlog`
--

LOCK TABLES `pay_blockedlog` WRITE;
/*!40000 ALTER TABLE `pay_blockedlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_blockedlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_browserecord`
--

DROP TABLE IF EXISTS `pay_browserecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_browserecord` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_browserecord`
--

LOCK TABLES `pay_browserecord` WRITE;
/*!40000 ALTER TABLE `pay_browserecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_browserecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_category`
--

DROP TABLE IF EXISTS `pay_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `pid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '父级ID',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态 1开启 0关闭',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='文章栏目';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_category`
--

LOCK TABLES `pay_category` WRITE;
/*!40000 ALTER TABLE `pay_category` DISABLE KEYS */;
INSERT INTO `pay_category` VALUES (1,'最新资讯',0,1),(2,'公司新闻',0,1),(3,'公告通知',1,1),(4,'站内公告',3,1),(5,'公司新闻',3,1);
/*!40000 ALTER TABLE `pay_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_channel`
--

DROP TABLE IF EXISTS `pay_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_channel` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '供应商通道ID',
  `code` varchar(200) DEFAULT NULL COMMENT '供应商通道英文编码',
  `title` varchar(200) DEFAULT NULL COMMENT '供应商通道名称',
  `mch_id` varchar(100) DEFAULT NULL COMMENT '商户号',
  `signkey` varchar(500) DEFAULT NULL COMMENT '签文密钥',
  `appid` varchar(100) DEFAULT NULL COMMENT '应用APPID',
  `appsecret` varchar(100) DEFAULT NULL COMMENT '安全密钥',
  `gateway` varchar(300) DEFAULT NULL COMMENT '网关地址',
  `notify_ip` text COMMENT '允许回调IP',
  `pagereturn` varchar(255) DEFAULT NULL COMMENT '页面跳转网址',
  `serverreturn` varchar(255) DEFAULT NULL COMMENT '服务器通知网址',
  `defaultrate` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT '下家费率',
  `fengding` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT '封顶手续费',
  `rate` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT '银行费率',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上次更改时间',
  `unlockdomain` varchar(100) NOT NULL COMMENT '防封域名',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态 1开启 0关闭',
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '渠道类型: 1 微信扫码 2 微信H5 3 支付宝扫码 4 支付宝H5 5网银跳转 6网银直连 7百度钱包 8 QQ钱包 9 京东钱包',
  `start_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '开始时间',
  `end_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '结束时间',
  `paying_money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '当天交易金额',
  `all_money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '当天上游可交易量',
  `last_paying_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后交易时间',
  `min_money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '单笔最小交易额',
  `max_money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '单笔最大交易额',
  `control_status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '风控状态:0否1是',
  `offline_status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '通道上线状态:0已下线，1上线',
  `t0defaultrate` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT 'T0运营费率',
  `t0fengding` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT 'T0封顶手续费',
  `t0rate` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT 'T0成本费率',
  `gudingmoney` varchar(800) DEFAULT NULL COMMENT '固定金额列表',
  `iphei` varchar(3000) DEFAULT NULL,
  `fudong_status` int(1) DEFAULT '0' COMMENT '浮动金额开关',
  `fudong_money` int(2) DEFAULT NULL COMMENT '浮动金额',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8 COMMENT='供应商列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_channel`
--

LOCK TABLES `pay_channel` WRITE;
/*!40000 ALTER TABLE `pay_channel` DISABLE KEYS */;
INSERT INTO `pay_channel` VALUES (109,'Zyoueke','中油H5','','','','','https://zshihua.wujianglong.com.cn/','','','',0.0000,0.0000,0.0000,1652548570,'',0,4,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,1,0),(110,'Tranqi','天然气-支付宝h5','','','','','http://154.213.29.3:8081/merchant/order/create','','','',0.0000,0.0000,0.0000,1652547281,'',0,4,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,0,0),(111,'Zshihua','加油中石化','','','','','https://zshihua.wujianglong.com.cn/','','','',0.0000,0.0000,0.0000,1652548556,'',0,2,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,1,0),(112,'Qyalipay','H5签约alipay','','','','','http://39.104.15.99:8080/ctp_hz/view/server/batchpayment/addTrans.php','','','',0.0000,0.0000,0.0000,1652590864,'',0,4,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,0,0),(115,'Yhualipay','寅虎-支付宝H5话费','','','','','http://154.55.133.129:3456/v1/payment','','','',0.0000,0.0000,0.0000,1653058381,'',0,4,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,0,0),(116,'Yhuweixin','寅虎-微信H5话费','','','','','http://154.55.133.129:3456/v1/payment','','','',0.0000,0.0000,0.0000,1653061224,'',0,2,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,0,0),(117,'Jsonjuhe','天虎微信H5','','','','','http://shop.hefangfdc.com/Pay_Index.html','','','',0.0000,0.0000,0.0000,1653377040,'',0,2,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,0,0),(118,'Xinalipay','支付宝新H5','','','','','http://154.55.133.129:3456/v1/payment','','','',0.0000,0.0000,0.0000,1653504576,'',0,4,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,0,0),(119,'SandPay','杉德支付宝H5','','','','','https://cashier1.sandpay.com.cn/gw/web/order/create','','','',0.0000,0.0000,0.0000,1655783813,'',0,4,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,0,0),(121,'Wxfwspay','微信服务商模式-wx支付','','','','','https://mall.010bxjl.cn/pay/order','','','',0.0000,0.0000,0.0000,1655783968,'',0,2,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,0,0),(122,'SandWechat','杉德公众号','','','','','https://cashier.sandpay.com.cn/gateway/api/order/pay','','','',0.0000,0.0000,0.0000,1655831510,'',1,2,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,0,0),(123,'Aliwap','ALIPAYH5','','','','','','','','',0.0000,0.0000,0.0000,1656081795,'',0,4,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,0,0),(124,'Jmwxsm','微信小微H5','','','','','http://mct.hwylkj.com/Pay_Index.html','','','',0.0000,0.0000,0.0000,1656256379,'',1,2,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,0,0),(125,'SandWechath5','杉德公众号H5模式','','','','','https://cashier.sandpay.com.cn/gateway/api/order/pay','','','',0.0000,0.0000,0.0000,1656251480,'',1,2,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,0,0),(126,'Payeasenet','首信易收银台','','','','','https://apis.5upay.com/onlinePay/order','','','',0.0000,0.0000,0.0000,1656864568,'',1,9,0,0,0.00,0.00,0,0.00,0.00,0,1,0.0000,0.0000,0.0000,NULL,NULL,0,0);
/*!40000 ALTER TABLE `pay_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_channel_account`
--

DROP TABLE IF EXISTS `pay_channel_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_channel_account` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '供应商通道账号ID',
  `channel_id` smallint(6) unsigned NOT NULL COMMENT '通道id',
  `mch_id` varchar(100) DEFAULT NULL COMMENT '商户号',
  `signkey` varchar(500) DEFAULT NULL COMMENT '签文密钥',
  `appid` varchar(100) DEFAULT NULL COMMENT '应用APPID',
  `appsecret` varchar(2500) DEFAULT NULL COMMENT '安全密钥',
  `defaultrate` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT '下家费率',
  `fengding` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT '封顶手续费',
  `rate` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT '银行费率',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上次更改时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态 1开启 0关闭',
  `title` varchar(100) DEFAULT NULL COMMENT '账户标题',
  `weight` tinyint(2) DEFAULT NULL COMMENT '轮询权重',
  `custom_rate` tinyint(1) DEFAULT NULL COMMENT '是否自定义费率',
  `start_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '开始交易时间',
  `end_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '结束时间',
  `last_paying_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后一笔交易时间',
  `paying_money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '当天交易金额',
  `all_money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '单日可交易金额',
  `max_money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '单笔交易最大金额',
  `min_money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '单笔交易最小金额',
  `offline_status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '上线状态-1上线,0下线',
  `control_status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '风控状态-0不风控,1风控中',
  `is_defined` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否自定义:1-是,0-否',
  `unit_frist_paying_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '单位时间第一笔交易时间',
  `unit_paying_number` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '单时间交易笔数',
  `unit_paying_amount` decimal(11,0) unsigned NOT NULL DEFAULT '0' COMMENT '单位时间交易金额',
  `unit_interval` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '单位时间数值',
  `time_unit` char(1) NOT NULL DEFAULT 's' COMMENT '限制时间单位',
  `unit_number` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '单位时间次数',
  `unit_all_money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '单位时间金额',
  `t0defaultrate` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT 'T0运营费率',
  `t0fengding` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT 'T0封顶手续费',
  `t0rate` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT 'T0成本费率',
  `unlockdomain` varchar(255) NOT NULL COMMENT '防封域名',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COMMENT='供应商账号列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_channel_account`
--

LOCK TABLES `pay_channel_account` WRITE;
/*!40000 ALTER TABLE `pay_channel_account` DISABLE KEYS */;
INSERT INTO `pay_channel_account` VALUES (7,111,'1','938891be24f3240ebfc9b05b1741b6a9','','',0.0000,0.0000,0.0000,1652548454,1,'1',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(5,109,'1','938891be24f3240ebfc9b05b1741b6a9','','',0.0000,0.0000,0.0000,1652548414,1,'1',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(6,110,'1525426670176043008','8f9b623d6c0f14a913c9731d0bc18719','6009','6009',0.0000,0.0000,0.0000,1652547348,1,'1525426670176043008',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(8,112,'998800111','B9GVBKAG7COTVG8B','2002','2002',0.0000,0.0000,0.0000,1652590696,1,'998800111',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(23,126,'891937551','ty123456','','',0.0000,0.0000,0.0000,1656864535,1,'891937551',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(11,115,'65','65789ACB9144648E3C05486EE30402A7','112','',0.0000,0.0000,0.0000,1653058407,1,'65',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(12,116,'65','65789ACB9144648E3C05486EE30402A7','308','',0.0000,0.0000,0.0000,1653061495,1,'65',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(13,117,'10004','k9ay5bmwdtlwx7kl7sx9ezfqizsgz4p5','37','',0.0000,0.0000,0.0000,1653375626,1,'10004',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(14,118,'65','65789ACB9144648E3C05486EE30402A7','117','',0.0000,0.0000,0.0000,1653505651,1,'65',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(15,119,'6888801044179','123321','','',0.0000,0.0000,0.0000,1655783832,1,'6888801044179',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(22,125,'6888801044179','123321','wxa6fbe363534a2027','',0.0000,0.0000,0.0000,1656251594,1,'6888801044179',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(17,121,'10198','ead93ef5156390958c0ef9097a1e3f5f','1627133814','',0.0000,0.0000,0.0000,1655785985,1,'10198',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(18,122,'6888801044179','123321','wxa6fbe363534a2027','',0.0000,0.0000,0.0000,1655831951,1,'6888801044179',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(19,123,'2019061865632293','MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjCaMeMFij0RNMs23i7xaKRh05hHbPo20W0JETa1yVJiRHHUVmIUCT5x/STUBDxy4sp+ABMjj0kEzbzRo8DaND5UzuF2lZYB1h9IAaL+SRYAZNKy8ozYxPFmxijHDXlPwG7h+JQTMHl2wXc3dXPB80Jg+AT/zS13kfRQziCeObnSGzdB+Zy4dGh6KF7f7eZCGFG72dEzVelyFhaJM4fBWOqxSs89qRoSOPqEwol2CIVomtmNc9VpPnZmlm/JL4wsCIjU/The4vZ4ZvH7JDBYaFYPQSZVOq3sKbr7sU3wmOWW5PH9psZtAl42aGTQ8j3X4td/GcYR2zZxxB4q23MOfKQIDAQAB','2019061865632293','MIIEogIBAAKCAQEAlvoawSUu6OOyDivPo651aMJU+46OYPHcvlO8zQvNEKoYhiKMNkaKY5m1hRK99aOYbRztIVhBvyxtqhIpoLbmx6C+Ptunlztc8arQQvdvVT/lrGXUTdv9zB6dSlrfKNY7gBRkYW8upB/IcKJXsMi3Yrm0h/RvNzn2o3DaWg7rOYCXHUYkc0o9GenVp65760Np9W/8A3wqUcLHfekAev14yJtWyTzLQjBMxXgq0csW/DdIzG0qyE30N/K2XGuTf3FZ/ZdenyThPhxIow+7CrQ4cWMXRORn/vhIfZguCHiSIcLEBFASWRtqiaSUtoBcR+G2evvEY95yk5uzCbbdG4jxGQIDAQABAoIBABlMk8sl1fSEo0Oop8S/6UDCv8bfnpA0N09VbN/XSGeweSeRBnnZ3DrQeRBxkY9l+JbgMARUa8ADS+Uh4gPiYk21a+vQlwbKlcqRWxC9sdRRPsVi0u6xHJhl0OmyzI5lR9cwk5mYLfKmuMnXCma/W6uZft0BYtmYRvIgaRaKRXR/C/Arpu8XjITn8fYH6BXAo4KZY/70lpMBsDgciWrpxqXCEJhqV+TANLQDs9U8OpSy2IpSdq+0bojxdJHfcvxsapZXkU9ymXNZhUU79qYP+Y/BiImWqRJs8nroX+G9jtEIsXhP80DuuH6QjMwuMCe3pFWkm3Kc2U/Lhq3cdZ0jHwECgYEAxLzzVG/8ruhdellcBBUvLTZkPojQuFSpZKEhH+wDnTZ1yFuHQmq4fqcjgw1R20T2dzEjZ14RMadsqDQQqfi01YM6aQjjRpfEJw9XV9lsCc8gX3tf/CRhrBCucsAPknHKct+Mr/O+KQrx+9Bv14nZrtjgAQMyoCv7eQ+GetJfzNECgYEAxHRhYSEJT24ZXgK0au4Sh4uZ4EA9MiBWzhjby69NvY6uGmwmEn18VxaJD84rYRW44zPPozIINjN3hUq3BEpILDSRFy1z41WSoIKssCoWcg4eKN2JZPmjUVI5t1E8FsxH43dAJ337LVMJDIDrQoqor+hkX9u+5FbSkSCsCXsTUckCgYAQrcQjQGs3mNNz7+dxISqitp3A/3BScDr8IPzh6+xSg69wkPHim5GQizLjhVmPMUWDzVKnDL6AayU3DVLsVf1erIVjKjG6ZltmxFIvTGtwWXLxJVB528u7/p4LdGTdkXAMVQ9kS1GvwRHKu1z/9NvTiudSrqa4FYJ4POy1tOgSQQKBgCfO7WyhJSHTTZCfO6/vThHpV+T5H21o4C4jG2bKvxYKM31nLM/SXb/H8T4iqOejXzOq7AhFuyRAiZeY7D0SUE2k2UG5FCKc1HlyAUwxOxshgTsGqTCs5Us1PjzHWUXFX0vYfkeCX8NvcAX4mbOCJWx/ytch0Cy06zY9SJ8jMWcBAoGAYmqH9TDFJX41D4yi7exoxGxVYQ1IbFtvX7u9/FCQKz3otVe5qjfnVBn54bSyNioFYLvSwGgsO0F4xfKDXxpiXkFGUr/wKjSu5WNYBHB308yK/QpPndCSsVcyjU8YG7ZDGCKk9YwBJWmdlnvwUzSDZvIQx177Lp4vBjhYLA3pris=',0.0000,0.0000,0.0000,1656144554,1,'ynhqwang',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(20,123,'2021002129618266','MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuQDpqHofYpaGSClGZAS6GvtHDVtjGBdpNtH9Y1592JJ99WGcbmm+pplJdmDjj8slAslJMLXw2977tZlaZ9D+2zXyc2K0JW+FyO52RCvu6gf7WlxTcD3585Bsgkwj1D/fyJs9i/Bv7wij8op4LqSCWa5yfa/Aq6I65t6JdqaIVJohGshd/ONc1iBvoc741VWwVVB+BnTuXl0FDUpBQP347oh3VcHj02kwQl1FJxuIbT2e6H4i8duDKaUEsGWzCAbJHpHL5JrPuGbeCyEy0fiya4aLSccyOmdTZ77jNmdStZYz7mrnDBnivGQl+LZws7t7KSjEYJZlLJ68MnKtQnUxKwIDAQAB','2021002129618266','MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC5AOmoeh9iloZIKUZkBLoa+0cNW2MYF2k20f1jXn3Ykn31YZxuab6mmUl2YOOPyyUCyUkwtfDb3vu1mVpn0P7bNfJzYrQlb4XI7nZEK+7qB/taXFNwPfnzkGyCTCPUP9/Imz2L8G/vCKPyingupIJZrnJ9r8Crojrm3ol2pohUmiEayF3841zWIG+hzvjVVbBVUH4GdO5eXQUNSkFA/fjuiHdVwePTaTBCXUUnG4htPZ7ofiLx24MppQSwZbMIBskekcvkms+4Zt4LITLR+LJrhotJxzI6Z1NnvuM2Z1K1ljPuaucMGeK8ZCX4tnCzu3spKMRglmUsnrwycq1CdTErAgMBAAECggEAO8cHuOB886YfjYGItRix6bX3p2E4C7jEzmnbrhgCIdBz0q3Plf2lFL/C9PUpknTZaKUReSPQx7qtKmh6xcDKGJq91Hq4KsB2Qg6LOEvZztT1aqUacNIVyZWI+jEQAq0A6hj/MhBmmp34G46Sdr/BPqkXZXU8lDi/P4n4cNYuhucYXiGw6z7qhXKPNh2BClECfomNA+Zfn1zzMpPyrXa0gAS33TdniZ0jORxP55hIwq72VFJ/7qG1+Xii7Gj8K7O6IDHa4KVH+5FlEhpggshJqZJbti05OHrFJCxzHWK+qITrtPPXyzlz+8MX3dccYkqB+maedJc/Nfu/AiHTgHrLgQKBgQD7g7SE4OXFc1D/mhGSIDmF59epjdLEWMKqko51HMD/yJKlX7cO7VluzMzve/ONhPhgjw1KAgNQ9ER5fomYGOyAoHUuOYABaDsgc3D1RXmXj3tcCwO0BEF8M6lPd+SlnY7nGDrf5hKXX1fwHHlPtODcehyoxOmhyVnsF4iXS73+yQKBgQC8TYzxzumAgkcD/k05WeJ3arcSAv05t4AEN4c39bPPYjKnewgptDKcV69eCQ/9rRXXgOPJvT5dyafErZsCmjCNsSDVidVbspu6EY3HZkj9DKRQghCUrUAUJUSWn5aM2VCnh/O32t4B5SJpG2en5ME6uDpTkPeriHe4b6AIM9vmUwKBgBTN7yeypq7ve/q4ls18huWRqOAokA+Xu/p6Bvie+UPvJloxkaXVcjldDXKd0SaaoiTykEnX4shWfDeEhQMkxKNbInZBYVo8ce+cPPK83XLw9mZFrve8BmKsr0uYgjxEzSZGddBBarZEt7Rv1oUGVDdIjohTSXQNgLertqu1IzEpAoGBAIE9pPBOeJt4Ty+hefVUCQi3WOFm5dCYbqf2SLuSyxAasPOckPS2tknyMO4UwEH3a1dXIoDTf5u1jY2DLjIyDAMkQInvqV3fj9y8sZfbT1tHMvwC2UiCRMnO7m2HKTiQ6zehKxjUgq3AS8biRVnJuwoHahjzFdpItwsCqk8W8OX7AoGAXQccbP2yeBV9Y/0GjK6zKuET9FNvULvjQKlSIJLYtORT1hC09MEftkFCyyuCA13F9txbvZJthkf2S4mCP99FoHrQQqK8Lkc71ne3LCCVBstbjKLwVFYeVIM9WCLLv8mCnFOxLp6JloqUCbcm2yUZCaD9t9uxOUT5yuQPceE3GMM=',0.0000,0.0000,0.0000,1656128926,0,'客户的',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,''),(21,124,'10004','k9ay5bmwdtlwx7kl7sx9ezfqizsgz4p5','40','',0.0000,0.0000,0.0000,1656184914,1,'10004',1,0,0,0,0,0.00,0.00,0.00,0.00,0,0,0,0,0,0,0,'s',0,0.00,0.0000,0.0000,0.0000,'');
/*!40000 ALTER TABLE `pay_channel_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_complaints_deposit`
--

DROP TABLE IF EXISTS `pay_complaints_deposit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_complaints_deposit` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `pay_orderid` varchar(100) NOT NULL DEFAULT '0' COMMENT '系统订单号',
  `out_trade_id` varchar(50) NOT NULL DEFAULT '' COMMENT '下游订单号',
  `freeze_money` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '冻结保证金额',
  `unfreeze_time` int(11) NOT NULL DEFAULT '0' COMMENT '计划解冻时间',
  `real_unfreeze_time` int(11) NOT NULL DEFAULT '0' COMMENT '实际解冻时间',
  `is_pause` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否暂停解冻 0正常解冻 1暂停解冻',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '解冻状态 0未解冻 1已解冻',
  `create_at` int(11) NOT NULL COMMENT '记录创建时间',
  `update_at` int(11) NOT NULL COMMENT '记录更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_unfreezeing` (`status`,`is_pause`,`unfreeze_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='投诉保证金余额';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_complaints_deposit`
--

LOCK TABLES `pay_complaints_deposit` WRITE;
/*!40000 ALTER TABLE `pay_complaints_deposit` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_complaints_deposit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_complaints_deposit_rule`
--

DROP TABLE IF EXISTS `pay_complaints_deposit_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_complaints_deposit_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `is_system` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否系统规则 1是 0否',
  `ratio` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '投诉保证金比例（百分比）',
  `freeze_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '冻结时间（秒）',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '规则是否开启 1开启 0关闭',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='投诉保证金规则表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_complaints_deposit_rule`
--

LOCK TABLES `pay_complaints_deposit_rule` WRITE;
/*!40000 ALTER TABLE `pay_complaints_deposit_rule` DISABLE KEYS */;
INSERT INTO `pay_complaints_deposit_rule` VALUES (1,180586943,1,0.00,0,0),(2,1,0,0.00,0,0),(3,17,0,0.00,0,0),(4,5,0,0.00,0,0),(5,36,0,30.00,86400,1);
/*!40000 ALTER TABLE `pay_complaints_deposit_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_df_api_order`
--

DROP TABLE IF EXISTS `pay_df_api_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_df_api_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '商户编号',
  `trade_no` varchar(30) NOT NULL DEFAULT '' COMMENT '平台订单号',
  `out_trade_no` varchar(30) NOT NULL DEFAULT '' COMMENT '商户订单号',
  `money` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `bankname` varchar(100) NOT NULL DEFAULT '' COMMENT '银行名称',
  `subbranch` varchar(100) NOT NULL DEFAULT '' COMMENT '支行名称',
  `accountname` varchar(100) NOT NULL DEFAULT '' COMMENT '开户名',
  `cardnumber` varchar(100) NOT NULL DEFAULT '' COMMENT '银行卡号',
  `province` varchar(100) NOT NULL DEFAULT '' COMMENT '所属省',
  `city` varchar(100) NOT NULL DEFAULT '' COMMENT '所属市',
  `ip` varchar(100) DEFAULT '' COMMENT 'IP地址',
  `check_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0：待审核 1：已提交后台审核 2：审核驳回',
  `extends` text COMMENT '扩展字段',
  `df_id` int(11) NOT NULL DEFAULT '0' COMMENT '代付ID',
  `notifyurl` varchar(255) DEFAULT '' COMMENT '异步通知地址',
  `reject_reason` varchar(255) NOT NULL DEFAULT '' COMMENT '驳回原因',
  `check_time` int(11) NOT NULL DEFAULT '0' COMMENT '审核时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `df_charge_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '代付API扣除手续费方式，0：从到账金额里扣，1：从商户余额里扣',
  PRIMARY KEY (`id`),
  KEY `IND_UID` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_df_api_order`
--

LOCK TABLES `pay_df_api_order` WRITE;
/*!40000 ALTER TABLE `pay_df_api_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_df_api_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_email`
--

DROP TABLE IF EXISTS `pay_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_email` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `smtp_host` varchar(300) DEFAULT NULL,
  `smtp_port` varchar(300) DEFAULT NULL,
  `smtp_user` varchar(300) DEFAULT NULL,
  `smtp_pass` varchar(300) DEFAULT NULL,
  `smtp_email` varchar(300) DEFAULT NULL,
  `smtp_name` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_email`
--

LOCK TABLES `pay_email` WRITE;
/*!40000 ALTER TABLE `pay_email` DISABLE KEYS */;
INSERT INTO `pay_email` VALUES (1,'smtp.163.com','465','17000000000@163.com','xa811121','17000000000@163.com','聚合支付客服');
/*!40000 ALTER TABLE `pay_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_invitecode`
--

DROP TABLE IF EXISTS `pay_invitecode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_invitecode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invitecode` varchar(32) NOT NULL,
  `fmusernameid` int(11) unsigned NOT NULL DEFAULT '0',
  `syusernameid` int(11) NOT NULL DEFAULT '0',
  `regtype` tinyint(1) unsigned NOT NULL DEFAULT '4' COMMENT '用户组 4 普通用户 5 代理商',
  `fbdatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `yxdatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `sydatetime` int(11) unsigned DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '邀请码状态 0 禁用 1 未使用 2 已使用',
  `is_admin` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否管理员添加',
  PRIMARY KEY (`id`),
  UNIQUE KEY `invitecode` (`invitecode`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_invitecode`
--

LOCK TABLES `pay_invitecode` WRITE;
/*!40000 ALTER TABLE `pay_invitecode` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_invitecode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_inviteconfig`
--

DROP TABLE IF EXISTS `pay_inviteconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_inviteconfig` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invitezt` tinyint(1) unsigned DEFAULT '1',
  `invitetype2number` int(11) NOT NULL DEFAULT '20',
  `invitetype2ff` smallint(6) NOT NULL DEFAULT '1',
  `invitetype5number` int(11) NOT NULL DEFAULT '20',
  `invitetype5ff` smallint(6) NOT NULL DEFAULT '1',
  `invitetype6number` int(11) NOT NULL DEFAULT '20',
  `invitetype6ff` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_inviteconfig`
--

LOCK TABLES `pay_inviteconfig` WRITE;
/*!40000 ALTER TABLE `pay_inviteconfig` DISABLE KEYS */;
INSERT INTO `pay_inviteconfig` VALUES (1,0,0,0,10,0,0,0);
/*!40000 ALTER TABLE `pay_inviteconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_loginrecord`
--

DROP TABLE IF EXISTS `pay_loginrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_loginrecord` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL DEFAULT '0',
  `logindatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `loginip` varchar(100) NOT NULL,
  `loginaddress` varchar(300) DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型：0：前台用户 1：后台用户',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_loginrecord`
--

LOCK TABLES `pay_loginrecord` WRITE;
/*!40000 ALTER TABLE `pay_loginrecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_loginrecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_member`
--

DROP TABLE IF EXISTS `pay_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_member` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(32) NOT NULL COMMENT '密码',
  `groupid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '用户组',
  `salt` varchar(10) NOT NULL COMMENT '密码随机字符',
  `parentid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '代理ID',
  `agent_cate` int(11) NOT NULL DEFAULT '0' COMMENT '代理级别',
  `balance` decimal(15,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '可用余额',
  `blockedbalance` decimal(15,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '冻结可用余额',
  `email` varchar(100) NOT NULL,
  `activate` varchar(200) NOT NULL,
  `regdatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `activatedatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `realname` varchar(50) DEFAULT NULL COMMENT '姓名',
  `sex` tinyint(1) NOT NULL DEFAULT '1' COMMENT '性别',
  `birthday` int(11) NOT NULL DEFAULT '0',
  `sfznumber` varchar(20) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL COMMENT '联系电话',
  `qq` varchar(15) DEFAULT NULL COMMENT 'QQ',
  `address` varchar(200) DEFAULT NULL COMMENT '联系地址',
  `paypassword` varchar(32) DEFAULT NULL COMMENT '支付密码',
  `authorized` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 已认证 0 未认证 2 待审核',
  `apidomain` varchar(500) DEFAULT NULL COMMENT '授权访问域名',
  `apikey` varchar(32) NOT NULL COMMENT 'APIKEY',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态 1激活 0未激活',
  `receiver` varchar(255) DEFAULT NULL COMMENT '台卡显示的收款人信息',
  `unit_paying_number` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '单位时间已交易次数',
  `unit_paying_amount` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '单位时间已交易金额',
  `unit_frist_paying_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '单位时间已交易的第一笔时间',
  `last_paying_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '当天最后一笔已交易时间',
  `paying_money` decimal(15,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '当天已交易金额',
  `login_ip` varchar(255) NOT NULL DEFAULT ' ' COMMENT '登录IP',
  `pay_ip` varchar(100) DEFAULT NULL COMMENT '提交支付IP',
  `last_error_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录错误时间',
  `login_error_num` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '错误登录次数',
  `google_auth` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开启谷歌身份验证登录',
  `df_api` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开启代付API',
  `open_charge` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开启充值功能',
  `df_domain` text NOT NULL COMMENT '代付域名报备',
  `df_auto_check` tinyint(1) NOT NULL DEFAULT '0' COMMENT '代付API自动审核',
  `google_secret_key` varchar(255) NOT NULL DEFAULT '' COMMENT '谷歌密钥',
  `df_ip` text NOT NULL COMMENT '代付域名报备IP',
  `session_random` varchar(50) NOT NULL DEFAULT '' COMMENT 'session随机字符串',
  `df_charge_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '代付API扣除手续费方式，0：从到账金额里扣，1：从商户余额里扣',
  `last_login_time` int(11) NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_member`
--

LOCK TABLES `pay_member` WRITE;
/*!40000 ALTER TABLE `pay_member` DISABLE KEYS */;
INSERT INTO `pay_member` VALUES (4,'测试代付商户','af4e45a55213ed7ce0457f98e773483e',4,'7187',1,4,100000.00,0.00,'2222@qq.com','770ef98e0e5dd082eed02a68b50509eb',1658211857,2022,'测试代付商户',1,-28800,'254551515151','13852222222','2222','dali','e10adc3949ba59abbe56e057f20f883e',1,NULL,'9i9qa0qe9ldz5r1cn6hx5popvw26u92m',1,NULL,0,0.00,0,0,0.00,'','',0,0,0,1,0,'',1,'','','',0,0);
/*!40000 ALTER TABLE `pay_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_member_agent_cate`
--

DROP TABLE IF EXISTS `pay_member_agent_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_member_agent_cate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(50) DEFAULT NULL COMMENT '等级名',
  `desc` varchar(255) DEFAULT NULL COMMENT '等级描述',
  `ctime` int(11) DEFAULT '0' COMMENT '添加时间',
  `sort` int(11) DEFAULT '99' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_member_agent_cate`
--

LOCK TABLES `pay_member_agent_cate` WRITE;
/*!40000 ALTER TABLE `pay_member_agent_cate` DISABLE KEYS */;
INSERT INTO `pay_member_agent_cate` VALUES (4,'普通商户','',1522638122,99),(5,'普通代理商户','',1522638122,99),(6,'中级代理商户','',1522638122,99),(7,'高级代理商户','',1522638122,99);
/*!40000 ALTER TABLE `pay_member_agent_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_moneychange`
--

DROP TABLE IF EXISTS `pay_moneychange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_moneychange` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '商户编号',
  `ymoney` decimal(15,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '原金额',
  `money` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '变动金额',
  `gmoney` decimal(15,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '变动后金额',
  `datetime` datetime DEFAULT NULL COMMENT '修改时间',
  `transid` varchar(50) DEFAULT NULL COMMENT '交易流水号',
  `tongdao` smallint(6) unsigned DEFAULT '0' COMMENT '支付通道ID',
  `lx` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `tcuserid` int(11) DEFAULT NULL,
  `tcdengji` int(11) DEFAULT NULL,
  `orderid` varchar(50) DEFAULT NULL COMMENT '订单号',
  `contentstr` varchar(255) DEFAULT NULL COMMENT '备注',
  `t` int(4) NOT NULL DEFAULT '0' COMMENT '结算方式',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_moneychange`
--

LOCK TABLES `pay_moneychange` WRITE;
/*!40000 ALTER TABLE `pay_moneychange` DISABLE KEYS */;
INSERT INTO `pay_moneychange` VALUES (18,3,1003906.27,2.80,1003903.47,'2022-07-07 22:03:39','L0707026193899083',0,10,NULL,NULL,'L0707026193899083','2022-07-07 22:03:39委托提现操作',0),(19,3,1003903.47,1.00,1003902.47,'2022-07-07 22:03:39','L0707026193899083',0,14,NULL,NULL,'L0707026193899083','2022-07-07 22:03:39代付结算扣除手续费',0),(20,3,1003902.47,2.90,1003899.57,'2022-07-07 22:04:37','L0707026772561796',0,10,NULL,NULL,'L0707026772561796','2022-07-07 22:04:37委托提现操作',0),(21,3,1003899.57,1.00,1003898.57,'2022-07-07 22:04:37','L0707026772561796',0,14,NULL,NULL,'L0707026772561796','2022-07-07 22:04:37代付结算扣除手续费',0),(22,3,1003898.57,3.20,1003895.37,'2022-07-08 01:50:13','L0708162135414663',0,10,NULL,NULL,'L0708162135414663','2022-07-08 01:50:13委托提现操作',0),(23,3,1003895.37,1.00,1003894.37,'2022-07-08 01:50:13','L0708162135414663',0,14,NULL,NULL,'L0708162135414663','2022-07-08 01:50:13代付结算扣除手续费',0),(24,3,1003894.37,1.20,1003893.17,'2022-07-08 01:56:54','L0708166140867713',0,10,NULL,NULL,'L0708166140867713','2022-07-08 01:56:54委托提现操作',0),(25,3,1003893.17,1.00,1003892.17,'2022-07-08 01:56:54','L0708166140867713',0,14,NULL,NULL,'L0708166140867713','2022-07-08 01:56:54代付结算扣除手续费',0),(26,3,1003892.17,1.55,1003890.62,'2022-07-08 01:57:58','L0708166784749092',0,10,NULL,NULL,'L0708166784749092','2022-07-08 01:57:58委托提现操作',0),(27,3,1003890.62,1.00,1003889.62,'2022-07-08 01:57:58','L0708166784749092',0,14,NULL,NULL,'L0708166784749092','2022-07-08 01:57:58代付结算扣除手续费',0),(28,3,1003889.62,2.30,1003887.32,'2022-07-08 02:08:27','L0708173071866046',0,10,NULL,NULL,'L0708173071866046','2022-07-08 02:08:27委托提现操作',0),(29,3,1003887.32,1.00,1003886.32,'2022-07-08 02:08:27','L0708173071866046',0,14,NULL,NULL,'L0708173071866046','2022-07-08 02:08:27代付结算扣除手续费',0),(30,3,1003886.32,1.60,1003884.72,'2022-07-08 02:13:04','L0708175847950714',0,10,NULL,NULL,'L0708175847950714','2022-07-08 02:13:04委托提现操作',0),(31,3,1003884.72,1.00,1003883.72,'2022-07-08 02:13:04','L0708175847950714',0,14,NULL,NULL,'L0708175847950714','2022-07-08 02:13:04代付结算扣除手续费',0),(32,3,1003883.72,95.00,1003788.72,'2022-07-08 02:54:42','L0708200825637385',0,10,NULL,NULL,'L0708200825637385','2022-07-08 02:54:42委托提现操作',0),(33,3,1003788.72,1.00,1003787.72,'2022-07-08 02:54:42','L0708200825637385',0,14,NULL,NULL,'L0708200825637385','2022-07-08 02:54:42代付结算扣除手续费',0),(34,3,1003787.72,10.00,1003777.72,'2022-07-08 02:56:27','L0708201876856318',0,10,NULL,NULL,'L0708201876856318','2022-07-08 02:56:27委托提现操作',0),(35,3,1003777.72,1.00,1003776.72,'2022-07-08 02:56:27','L0708201876856318',0,14,NULL,NULL,'L0708201876856318','2022-07-08 02:56:27代付结算扣除手续费',0),(36,3,1003776.72,3.20,1003773.52,'2022-07-08 03:20:17','L0708216176494204',0,10,NULL,NULL,'L0708216176494204','2022-07-08 03:20:17委托提现操作',0),(37,3,1003773.52,1.00,1003772.52,'2022-07-08 03:20:17','L0708216176494204',0,14,NULL,NULL,'L0708216176494204','2022-07-08 03:20:17代付结算扣除手续费',0),(38,3,1003772.52,1.22,1003771.30,'2022-07-09 00:35:49','L0709981499239988',0,10,NULL,NULL,'L0709981499239988','2022-07-09 00:35:49委托提现操作',0),(39,3,1003771.30,1.00,1003770.30,'2022-07-09 00:35:49','L0709981499239988',0,14,NULL,NULL,'L0709981499239988','2022-07-09 00:35:49代付结算扣除手续费',0),(40,3,1003770.30,10000.00,993770.30,'2022-07-18 00:31:21','L0718754816357130',0,10,NULL,NULL,'L0718754816357130','2022-07-18 00:31:21委托提现操作',0),(41,3,993770.30,1.00,993769.30,'2022-07-18 00:31:21','L0718754816357130',0,14,NULL,NULL,'L0718754816357130','2022-07-18 00:31:21代付结算扣除手续费',0),(42,3,993769.30,10000.00,1003769.30,'2022-07-18 01:57:02','19',0,12,NULL,NULL,'19','代付驳回',0),(43,3,1003769.30,1.00,1003770.30,'2022-07-18 01:57:02','19',0,15,NULL,NULL,'19','代付结算驳回退回手续费',0),(44,3,1003770.30,100.00,1003670.30,'2022-07-18 01:57:14','L0718806349531094',0,10,NULL,NULL,'L0718806349531094','2022-07-18 01:57:14委托提现操作',0),(45,3,1003670.30,1.00,1003669.30,'2022-07-18 01:57:14','L0718806349531094',0,14,NULL,NULL,'L0718806349531094','2022-07-18 01:57:14代付结算扣除手续费',0),(46,3,1003669.30,20.20,1003649.10,'2022-07-18 13:17:55','L0718214756827987',0,10,NULL,NULL,'L0718214756827987','2022-07-18 13:17:55委托提现操作',0),(47,3,1003649.10,1.00,1003648.10,'2022-07-18 13:17:55','L0718214756827987',0,14,NULL,NULL,'L0718214756827987','2022-07-18 13:17:55代付结算扣除手续费',0),(48,3,1003648.10,10.00,1003638.10,'2022-07-18 14:40:12','L0718264122073658',0,10,NULL,NULL,'L0718264122073658','2022-07-18 14:40:12委托提现操作',0),(49,3,1003638.10,1.00,1003637.10,'2022-07-18 14:40:12','L0718264122073658',0,14,NULL,NULL,'L0718264122073658','2022-07-18 14:40:12代付结算扣除手续费',0),(50,3,1003637.10,10.00,1003647.10,'2022-07-19 13:58:46','22',0,12,NULL,NULL,'22','代付驳回',0),(51,3,1003647.10,1.00,1003648.10,'2022-07-19 13:58:46','22',0,15,NULL,NULL,'22','代付结算驳回退回手续费',0),(52,4,0.00,100000.00,100000.00,'2022-07-19 14:24:26','',0,3,NULL,NULL,'','0【冲正周期:2022-07-19】',0);
/*!40000 ALTER TABLE `pay_moneychange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_order`
--

DROP TABLE IF EXISTS `pay_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pay_memberid` varchar(100) NOT NULL COMMENT '商户编号',
  `pay_username` varchar(200) DEFAULT NULL COMMENT '用户名',
  `pay_orderid` varchar(100) NOT NULL COMMENT '系统订单号',
  `pay_amount` decimal(15,2) unsigned NOT NULL DEFAULT '0.00',
  `true_amount` decimal(50,2) DEFAULT NULL COMMENT '实付金额',
  `pay_poundage` decimal(15,2) unsigned NOT NULL DEFAULT '0.00',
  `pay_actualamount` decimal(15,2) unsigned NOT NULL DEFAULT '0.00',
  `pay_applydate` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '订单创建日期',
  `pay_successdate` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '订单支付成功时间',
  `pay_bankcode` varchar(100) DEFAULT NULL COMMENT '银行编码',
  `pay_notifyurl` varchar(500) NOT NULL COMMENT '商家异步通知地址',
  `pay_callbackurl` varchar(500) NOT NULL COMMENT '商家页面通知地址',
  `pay_bankname` varchar(300) DEFAULT NULL,
  `pay_status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '订单状态: 0 未支付 1 已支付未返回 2 已支付已返回',
  `pay_productname` varchar(80) DEFAULT NULL COMMENT '商品名称',
  `pay_tongdao` varchar(50) DEFAULT NULL,
  `pay_zh_tongdao` varchar(50) DEFAULT NULL,
  `pay_tjurl` varchar(1000) DEFAULT NULL,
  `out_trade_id` varchar(50) NOT NULL COMMENT '商户订单号',
  `num` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '已补发次数',
  `memberid` varchar(100) DEFAULT NULL COMMENT '支付渠道商家号',
  `key` varchar(500) DEFAULT NULL COMMENT '支付渠道密钥',
  `account` varchar(100) DEFAULT NULL COMMENT '渠道账号',
  `isdel` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '伪删除订单 1 删除 0 未删',
  `ddlx` int(11) DEFAULT '0',
  `pay_ytongdao` varchar(50) DEFAULT NULL,
  `pay_yzh_tongdao` varchar(50) DEFAULT NULL,
  `xx` smallint(6) unsigned NOT NULL DEFAULT '0',
  `attach` varchar(100) DEFAULT NULL COMMENT '商家附加字段,原样返回',
  `pay_channel_account` varchar(255) DEFAULT NULL COMMENT '通道账户',
  `cost` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT '成本',
  `cost_rate` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT '成本费率',
  `account_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '子账号id',
  `channel_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '渠道id',
  `t` tinyint(2) NOT NULL DEFAULT '1' COMMENT '结算周期（计算费率）',
  `last_reissue_time` int(11) NOT NULL DEFAULT '11' COMMENT '最后补发时间',
  `lock_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `yichangip` varchar(60) DEFAULT NULL,
  `order_ip` varchar(32) DEFAULT NULL COMMENT '客户端IP',
  `yichang` int(12) NOT NULL,
  `is_budan` int(12) NOT NULL,
  `mobile` varchar(64) DEFAULT NULL COMMENT '客户端类型',
  `huidiao_url` varchar(300) DEFAULT NULL COMMENT '上游给发送回调的url',
  `tijiaomoey` varchar(200) DEFAULT NULL COMMENT '提交金额备注',
  `notify_msg` varchar(500) DEFAULT NULL COMMENT '发送回调下游返回内容',
  `tongdao_msg` text COMMENT '上游回调内容',
  `qyalipay_uid` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IND_ORD` (`pay_orderid`),
  KEY `account_id` (`account_id`),
  KEY `channel_id` (`channel_id`),
  KEY `id` (`id`),
  KEY `pay_memberid` (`pay_memberid`),
  KEY `pay_orderid` (`pay_orderid`),
  KEY `pay_amount` (`pay_amount`),
  KEY `pay_applydate` (`pay_applydate`),
  KEY `pay_successdate` (`pay_successdate`),
  KEY `pay_status` (`pay_status`),
  KEY `memberid` (`memberid`)
) ENGINE=MyISAM AUTO_INCREMENT=703 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_order`
--

LOCK TABLES `pay_order` WRITE;
/*!40000 ALTER TABLE `pay_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_pay_channel_extend_fields`
--

DROP TABLE IF EXISTS `pay_pay_channel_extend_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_pay_channel_extend_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel_id` int(11) NOT NULL DEFAULT '0' COMMENT '代付渠道ID',
  `code` varchar(64) NOT NULL DEFAULT '' COMMENT '代付渠道代码',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '扩展字段名',
  `alias` varchar(50) NOT NULL DEFAULT '' COMMENT '扩展字段别名',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `etime` int(11) NOT NULL DEFAULT '0' COMMENT '修改时间',
  `ctime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_pay_channel_extend_fields`
--

LOCK TABLES `pay_pay_channel_extend_fields` WRITE;
/*!40000 ALTER TABLE `pay_pay_channel_extend_fields` DISABLE KEYS */;
INSERT INTO `pay_pay_channel_extend_fields` VALUES (1,1,'Yibao','bankProvinceName','银行卡的所在省名称','',1533622880,1533622880),(2,1,'Yibao','bankProvinceCode','银行卡的所在省编码','',1533622891,1533622891),(3,1,'Yibao','bankCityName','银行卡的所在市名称','',1533622901,1533622901),(4,1,'Yibao','bankCityCode','银行卡的所在市编码','',1533622911,1533622911),(5,1,'Yibao','bankAreaName','银行卡的所在区名称','',1533622932,1533622932),(6,1,'Yibao','bankAreaCode','银行卡的所在区编码','',1533622945,1533622945),(7,1,'Yibao','bankId','银行卡的开户行编号','',1533622956,1533622956),(8,1,'Yibao','bankUserCert','银行卡的持卡人身份证','',1533622969,1533622969),(9,1,'Yibao','bankUserPhone','银行卡的预留手机号','',1533622991,1533622991);
/*!40000 ALTER TABLE `pay_pay_channel_extend_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_pay_for_another`
--

DROP TABLE IF EXISTS `pay_pay_for_another`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_pay_for_another` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `code` varchar(64) NOT NULL COMMENT '代付代码',
  `title` varchar(64) NOT NULL COMMENT '代付名称',
  `mch_id` varchar(255) NOT NULL DEFAULT ' ' COMMENT '商户号',
  `appid` varchar(100) NOT NULL DEFAULT ' ' COMMENT '应用APPID',
  `appsecret` varchar(100) NOT NULL DEFAULT ' ' COMMENT '应用密钥',
  `signkey` varchar(500) NOT NULL DEFAULT ' ' COMMENT '加密的秘钥',
  `public_key` varchar(1000) NOT NULL DEFAULT '  ' COMMENT '加密的公钥',
  `private_key` varchar(1000) NOT NULL DEFAULT '  ' COMMENT '加密的私钥',
  `exec_gateway` varchar(255) NOT NULL DEFAULT ' ' COMMENT '请求代付的地址',
  `query_gateway` varchar(255) NOT NULL DEFAULT ' ' COMMENT '查询代付的地址',
  `serverreturn` varchar(255) NOT NULL DEFAULT ' ' COMMENT '服务器通知网址',
  `unlockdomain` varchar(255) NOT NULL DEFAULT ' ' COMMENT '防封域名',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更改时间',
  `status` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '状态 1开启 0关闭',
  `is_default` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否默认：1是，0否',
  `cost_rate` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT '成本费率',
  `rate_type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '费率类型：按单笔收费0，按比例收费：1',
  PRIMARY KEY (`id`),
  KEY `code` (`code`),
  KEY `updatetime` (`updatetime`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='代付通道表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_pay_for_another`
--

LOCK TABLES `pay_pay_for_another` WRITE;
/*!40000 ALTER TABLE `pay_pay_for_another` DISABLE KEYS */;
INSERT INTO `pay_pay_for_another` VALUES (3,'HeePay','汇付宝代付','2137884','','EDC8AAD880374EA8A4ED0A0A','059369F9BBFD403BBB1963A5','','','','','','',1657121857,0,0,0.0000,0),(4,'ShanDe','衫德代付','6888801044139','','','414427','/www/wwwroot/daifu.fk08.cn/Data/cert/sand.cer','/www/wwwroot/daifu.fk08.cn/Data/cert/MID_RSA_PRIVATE.pfx','','','','',1658079272,1,1,0.0000,0);
/*!40000 ALTER TABLE `pay_pay_for_another` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_paylog`
--

DROP TABLE IF EXISTS `pay_paylog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_paylog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `out_trade_no` varchar(50) NOT NULL,
  `result_code` varchar(50) NOT NULL,
  `transaction_id` varchar(50) NOT NULL,
  `fromuser` varchar(50) NOT NULL,
  `time_end` int(11) unsigned NOT NULL DEFAULT '0',
  `total_fee` smallint(6) unsigned NOT NULL DEFAULT '0',
  `payname` varchar(50) NOT NULL,
  `bank_type` varchar(20) DEFAULT NULL,
  `trade_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IND_TRD` (`transaction_id`),
  UNIQUE KEY `IND_ORD` (`out_trade_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_paylog`
--

LOCK TABLES `pay_paylog` WRITE;
/*!40000 ALTER TABLE `pay_paylog` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_paylog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_product`
--

DROP TABLE IF EXISTS `pay_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_product` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '通道名称',
  `code` varchar(50) NOT NULL COMMENT '通道代码',
  `polling` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '接口模式 0 单独 1 轮询',
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '支付类型 1 微信扫码 2 微信H5 3 支付宝扫码 4 支付宝H5 5 网银跳转 6网银直连  7 百度钱包  8 QQ钱包 9 京东钱包',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `isdisplay` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '用户端显示 1 显示 0 不显示',
  `channel` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '通道ID',
  `weight` text COMMENT '平台默认通道权重',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=949 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_product`
--

LOCK TABLES `pay_product` WRITE;
/*!40000 ALTER TABLE `pay_product` DISABLE KEYS */;
INSERT INTO `pay_product` VALUES (933,'加油中石化WXh5','jiayou',0,2,0,0,111,''),(934,'中油好客H5','Zyouhaoke',0,4,0,0,109,''),(932,'天然气 支付宝h5','Tqixian',0,4,0,0,110,''),(935,'H5签约alipay','Qyalipay',0,4,0,0,112,''),(936,'小微	','JuHe',0,2,1,1,124,''),(937,'聚合-衫德','JuHe',0,2,0,0,114,''),(938,'寅虎-支付宝H5话费','Yhualip',0,4,0,0,0,''),(939,'寅虎-微信H5话费','yhweixin',0,2,0,0,116,''),(940,'天虎微信H5','Tianhuwx',0,2,0,0,117,''),(941,'支付宝新H5','Xinalipa',0,4,0,0,118,''),(942,'微信服务商模式-wx支付','Wxfwspay',0,2,0,0,121,''),(943,'衫德收银台','alipayh5',0,4,0,0,119,''),(944,'杉德公众号','WXxiaoh5',0,2,1,1,122,''),(947,'杉德公众号H5模式','Shandenh5',0,2,1,1,125,''),(945,'支付宝H5','ALIPAYH5',0,4,0,0,123,''),(946,'微信小微H5','Jmwxsm',0,2,0,0,124,''),(948,'收银台','syt',0,9,1,1,0,'');
/*!40000 ALTER TABLE `pay_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_product_user`
--

DROP TABLE IF EXISTS `pay_product_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_product_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT ' ',
  `userid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '商户编号',
  `pid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '商户通道ID',
  `polling` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '接口模式：0 单独 1 轮询',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '通道状态 0 关闭 1 启用',
  `channel` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '指定单独通道ID',
  `weight` varchar(255) DEFAULT NULL COMMENT '通道权重',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_product_user`
--

LOCK TABLES `pay_product_user` WRITE;
/*!40000 ALTER TABLE `pay_product_user` DISABLE KEYS */;
INSERT INTO `pay_product_user` VALUES (1,1,901,0,1,101,''),(2,1,903,0,0,0,''),(3,1,904,0,1,108,''),(4,1,927,0,0,0,''),(5,1,930,0,0,0,''),(6,1,931,0,0,0,''),(7,3,904,0,1,109,''),(8,3,932,0,1,110,''),(9,3,933,0,1,111,''),(10,3,934,0,1,109,''),(11,3,935,0,1,112,''),(12,3,936,0,0,124,''),(13,3,937,0,1,114,''),(14,3,938,0,1,115,''),(15,3,939,0,1,116,''),(16,3,940,0,1,117,''),(17,3,941,0,1,118,''),(18,3,943,0,1,119,''),(19,3,944,0,0,122,''),(20,3,942,0,1,121,''),(21,3,945,0,1,123,''),(22,3,946,0,1,124,''),(23,3,947,0,0,125,''),(24,3,948,0,0,126,'');
/*!40000 ALTER TABLE `pay_product_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_reconciliation`
--

DROP TABLE IF EXISTS `pay_reconciliation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_reconciliation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT '0' COMMENT '用户ID',
  `order_total_count` int(11) DEFAULT '0' COMMENT '总订单数',
  `order_success_count` int(11) DEFAULT '0' COMMENT '成功订单数',
  `order_fail_count` int(11) DEFAULT '0' COMMENT '未支付订单数',
  `order_total_amount` decimal(11,2) DEFAULT '0.00' COMMENT '订单总额',
  `order_success_amount` decimal(11,2) DEFAULT '0.00' COMMENT '订单实付总额',
  `date` date DEFAULT NULL COMMENT '日期',
  `ctime` int(11) DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_reconciliation`
--

LOCK TABLES `pay_reconciliation` WRITE;
/*!40000 ALTER TABLE `pay_reconciliation` DISABLE KEYS */;
INSERT INTO `pay_reconciliation` VALUES (1,1,0,0,0,NULL,NULL,'2022-03-31',1648711638),(2,1,36,8,28,775.00,117.00,'2022-03-30',1648711639),(3,1,1,1,0,100.00,NULL,'2022-03-29',1648711639),(4,1,2,0,2,200.00,NULL,'2022-03-28',1648711639),(5,3,0,0,0,NULL,NULL,'2022-04-26',1650969167),(6,3,0,0,0,NULL,NULL,'2022-04-25',1650969167),(7,3,0,0,0,NULL,NULL,'2022-04-24',1650969167),(8,3,0,0,0,NULL,NULL,'2022-04-23',1650969167),(9,3,0,0,0,NULL,NULL,'2022-04-22',1650969167),(10,3,0,0,0,NULL,NULL,'2022-04-21',1650969167),(11,3,0,0,0,NULL,NULL,'2022-04-20',1650969167),(12,3,0,0,0,NULL,NULL,'2022-04-19',1650969167),(13,3,0,0,0,NULL,NULL,'2022-04-18',1650969167),(14,3,0,0,0,NULL,NULL,'2022-04-17',1650969167),(15,3,0,0,0,NULL,NULL,'2022-04-16',1650969167),(16,3,0,0,0,NULL,NULL,'2022-04-15',1650969167),(17,3,0,0,0,NULL,NULL,'2022-04-14',1650969167),(18,3,0,0,0,NULL,NULL,'2022-04-13',1650969167),(19,3,0,0,0,NULL,NULL,'2022-04-12',1650969167),(20,3,0,0,0,NULL,NULL,'2022-07-08',1657226238),(21,3,0,0,0,NULL,NULL,'2022-07-07',1657226238),(22,3,0,0,0,NULL,NULL,'2022-07-06',1657226238),(23,3,0,0,0,NULL,NULL,'2022-07-05',1657226238),(24,3,0,0,0,NULL,NULL,'2022-07-04',1657226238),(25,3,0,0,0,NULL,NULL,'2022-07-03',1657226238),(26,3,0,0,0,NULL,NULL,'2022-07-02',1657226238),(27,3,0,0,0,NULL,NULL,'2022-07-01',1657226238),(28,3,0,0,0,NULL,NULL,'2022-06-30',1657226238),(29,3,0,0,0,NULL,NULL,'2022-06-29',1657226238),(30,3,0,0,0,NULL,NULL,'2022-06-28',1657226238),(31,3,0,0,0,NULL,NULL,'2022-06-27',1657226238),(32,3,0,0,0,NULL,NULL,'2022-06-26',1657226238),(33,3,0,0,0,NULL,NULL,'2022-06-25',1657226238),(34,3,0,0,0,NULL,NULL,'2022-06-24',1657226238),(35,NULL,0,0,0,NULL,NULL,'2022-07-08',1657255129),(36,NULL,0,0,0,NULL,NULL,'2022-07-07',1657255129),(37,NULL,0,0,0,NULL,NULL,'2022-07-06',1657255129),(38,NULL,0,0,0,NULL,NULL,'2022-07-05',1657255129),(39,NULL,0,0,0,NULL,NULL,'2022-07-04',1657255129),(40,NULL,0,0,0,NULL,NULL,'2022-07-03',1657255129),(41,NULL,0,0,0,NULL,NULL,'2022-07-02',1657255129),(42,NULL,0,0,0,NULL,NULL,'2022-07-01',1657255129),(43,NULL,0,0,0,NULL,NULL,'2022-06-30',1657255129),(44,NULL,0,0,0,NULL,NULL,'2022-06-29',1657255129),(45,NULL,0,0,0,NULL,NULL,'2022-06-28',1657255129),(46,NULL,0,0,0,NULL,NULL,'2022-06-27',1657255129),(47,NULL,0,0,0,NULL,NULL,'2022-06-26',1657255129),(48,NULL,0,0,0,NULL,NULL,'2022-06-25',1657255129),(49,NULL,0,0,0,NULL,NULL,'2022-06-24',1657255129);
/*!40000 ALTER TABLE `pay_reconciliation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_redo_order`
--

DROP TABLE IF EXISTS `pay_redo_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_redo_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL DEFAULT '0' COMMENT '操作管理员',
  `money` decimal(15,2) NOT NULL DEFAULT '0.00',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1：增加 2：减少',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '冲正备注',
  `date` datetime NOT NULL COMMENT '冲正周期',
  `ctime` int(11) NOT NULL DEFAULT '0' COMMENT '操作时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_redo_order`
--

LOCK TABLES `pay_redo_order` WRITE;
/*!40000 ALTER TABLE `pay_redo_order` DISABLE KEYS */;
INSERT INTO `pay_redo_order` VALUES (1,1,505,10000.00,1,'ggg【冲正周期:2022-03-30】','2022-03-30 00:00:00',1648601152),(2,3,505,1000000.00,1,'测试用【冲正周期:2022-07-06】','2022-07-06 00:00:00',1657122156),(3,4,505,100000.00,1,'0【冲正周期:2022-07-19】','2022-07-19 00:00:00',1658211866);
/*!40000 ALTER TABLE `pay_redo_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_route`
--

DROP TABLE IF EXISTS `pay_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_route` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `urlstr` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_route`
--

LOCK TABLES `pay_route` WRITE;
/*!40000 ALTER TABLE `pay_route` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_sms`
--

DROP TABLE IF EXISTS `pay_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_sms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `app_key` varchar(255) DEFAULT NULL COMMENT 'App Key',
  `app_secret` varchar(255) DEFAULT NULL COMMENT 'App Secret',
  `sign_name` varchar(255) DEFAULT NULL COMMENT '默认签名',
  `is_open` int(11) DEFAULT '0' COMMENT '是否开启，0关闭，1开启',
  `admin_mobile` varchar(255) DEFAULT NULL COMMENT '管理员接收手机',
  `is_receive` int(11) DEFAULT '0' COMMENT '是否开启，0关闭，1开启',
  `sms_channel` varchar(20) NOT NULL DEFAULT 'aliyun' COMMENT '短信通道',
  `smsbao_user` varchar(50) NOT NULL DEFAULT '' COMMENT '短信宝账号',
  `smsbao_pass` varchar(50) NOT NULL DEFAULT '' COMMENT '短信宝密码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_sms`
--

LOCK TABLES `pay_sms` WRITE;
/*!40000 ALTER TABLE `pay_sms` DISABLE KEYS */;
INSERT INTO `pay_sms` VALUES (3,'LTAIdnGHysawLyL2','TFpAmGsvH6RgPF9sS5ZvbgDC3wwNFP','MT聚合支付',0,NULL,0,'aliyun','111','11112');
/*!40000 ALTER TABLE `pay_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_sms_template`
--

DROP TABLE IF EXISTS `pay_sms_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_sms_template` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `template_code` varchar(255) DEFAULT NULL COMMENT '模板代码',
  `call_index` varchar(255) DEFAULT NULL COMMENT '调用字符串',
  `template_content` text COMMENT '模板内容',
  `ctime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_sms_template`
--

LOCK TABLES `pay_sms_template` WRITE;
/*!40000 ALTER TABLE `pay_sms_template` DISABLE KEYS */;
INSERT INTO `pay_sms_template` VALUES (3,'修改支付密码','SMS_144455941 ','editPayPassword','您正在进行修改支付密码操作，验证码为：${code} ，该验证码 5 分钟内有效，请勿泄露于他人。',1512202260),(4,'修改登录密码','SMS_169902581','editPasswordSend','您的验证码为：${code} ，你正在进行修改登录密码操作，该验证码 5 分钟内有效，请勿泄露于他人。',1512190115),(5,'异地登录','SMS_144455604','loginWarning','检测到您的账号登录异常，如非本人操纵，请及时修改账号密码。',1512202260),(6,'申请结算','SMS_144456102','clearing','您的申请结算验证码为：${code}  ，验证码只用于平台结算验证，为了您的资金安全，打死也不能告诉任何人。',1512202260),(7,'委托结算','SMS_144450916','entrusted','您的验证码为：${code} ，你正在进行 委托结算 操作，该验证码 5 分钟内有效，请勿泄露于他人。',1512202260),(8,'绑定手机','SMS_144455941 ','bindMobile','您的验证码为：${code} ，你正在进行 绑定手机 操作，该验证码 5 分钟内有效，请勿泄露于他人。',1514534290),(9,'更新手机','SMS_144450938','editMobile','您的验证码为：${code} ，你正在进行 更新手机 号码操作，该验证码 5 分钟内有效，请勿泄露于他人。',1514535688),(10,'更新银行卡 ','SMS_144450919','addBankcardSend','您的验证码为：${code} ，你正在进行 更新银行卡 \r\n 操作，该验证码 5 分钟内有效，请勿泄露于他人。',1514535688),(11,'修改个人资料','SMS_144450923','saveProfile','您的验证码为：${code} ，你正在进行 修改个人资料 操作，该验证码 5 分钟内有效，请勿泄露于他人。',151453568),(12,'绑定管理员手机号码','SMS_144450927','adminbindMobile','您的验证码为：${code} ，你正在进行 绑定管理员手机号码 操作，该验证码 5 分钟内有效，请勿泄露于他人。',1527670734),(13,'修改管理员手机号码','SMS_144455951','admineditMobile','您的验证码为：${code} ，你正在进行 修改管理员手机号码 操作，该验证码 5 分钟内有效，请勿泄露于他人。',1527670734),(14,'批量删除订单','SMS_144455956','delOrderSend','您的验证码为：${code} ，你正在进行 批量删除订单  操作，该验证码 5 分钟内有效，请勿泄露于他人。',1527670734),(15,'解绑谷歌身份验证器','SMS_119087905','unbindGoogle','您的验证码为：${code} ，你正在进行 解绑谷歌身份验证器 操作，该验证码 5 分钟内有效，请勿泄露于他人。',1527670734),(16,'设置订单为已支付','SMS_144455959','setOrderPaidSend','您的验证码为：${code} ，你正在进行 设置订单为已支付 操作，该验证码 5 分钟内有效，请勿泄露于他人。',1527670734),(17,'清理数据','SMS_169897576','clearDataSend','您的验证码为：${code} ，你正在进行 清理数据 操作，该验证码 5 分钟内有效，请勿泄露于他人。',1527670734),(18,'增加/减少余额（冲正）','SMS_111795375','adjustUserMoneySend','您的验证码为：${code} ，你正在进行 增加/减少余额（冲正） 操作，该验证码 5 分钟内有效，请勿泄露于他人。',1527670734),(19,'提交代付','SMS_144450941','submitDfSend','您的提交代付验证码为：${code} ，该验证码 5 分钟内有效，请勿泄露于他人。',1527670734),(20,'测试短信','SMS_169902737','test','您的测试短信验证码为：${code} ，您正在进行重要操作，该验证码 5 分钟内有效，请勿泄露于他人。',1527670734),(21,'系统配置','SMS_169902614','sysconfigSend','您的系统配置验证码为：${code} ，该验证码 5 分钟内有效，请勿泄露于他人。',1527670734),(22,'客户提现提醒','SMS_144455785','tixian','平台有客户申请提现，请及时处理！',1536649511);
/*!40000 ALTER TABLE `pay_sms_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_systembank`
--

DROP TABLE IF EXISTS `pay_systembank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_systembank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bankcode` varchar(100) DEFAULT NULL,
  `bankname` varchar(300) DEFAULT NULL,
  `images` varchar(300) DEFAULT NULL,
  `df_code` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=198 DEFAULT CHARSET=utf8 COMMENT='结算银行';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_systembank`
--

LOCK TABLES `pay_systembank` WRITE;
/*!40000 ALTER TABLE `pay_systembank` DISABLE KEYS */;
INSERT INTO `pay_systembank` VALUES (165,'ICBC','中国工商银行','ICBC.gif',1),(166,'CEB','中国光大银行','CEB.gif',8),(167,'GDB','广发银行','GDB.gif',11),(168,'HXB','华夏银行','HXB.gif',10),(169,'CCB','中国建设银行','CCB.gif',2),(170,'BCM','交通银行','BCM.gif',6),(171,'CMSB','中国民生银行','CMSB.gif',14),(172,'NJCB','南京银行','NJCB.gif',21),(173,'NBCB','宁波银行','NBCB.gif',17),(174,'ABC','中国农业银行','5414c87492ad8.gif',3),(175,'PAB','平安银行','5414c0929a632.gif',18),(176,'BOS','上海银行','BOS.gif',16),(179,'CIB','兴业银行','CIB.gif',13),(180,'PSBC','中国邮政储蓄银行','PSBC.gif',4),(181,'CMBC','招商银行','CMBC.gif',7),(182,'CZB','杭州银行','CZB.gif',15),(183,'BOC','中国银行','BOC.gif',5),(184,'CNCB','中信银行','CNCB.gif',12),(193,'ALIPAY','支付宝','58b83a5820644.jpg',0),(194,'WXZF','微信支付','58b83a757a298.jpg',0);
/*!40000 ALTER TABLE `pay_systembank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_template`
--

DROP TABLE IF EXISTS `pay_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_template` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT ' ' COMMENT '模板名称',
  `theme` varchar(255) NOT NULL DEFAULT ' ' COMMENT '模板代码',
  `is_default` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否默认模板:1是，0否',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `remarks` varchar(255) NOT NULL DEFAULT ' ' COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='模板表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_template`
--

LOCK TABLES `pay_template` WRITE;
/*!40000 ALTER TABLE `pay_template` DISABLE KEYS */;
INSERT INTO `pay_template` VALUES (1,' 默认模板','default',0,1524299660,1524299660,' 默认模板 无法删除 QQ1968984054原创模板'),(2,'2018新模板','view4',0,1555072900,1555072900,'包含所有页面-推荐QQ1968984054'),(3,'模板二','view2',0,1541007060,1541007060,'默认模板二，有登录页，注册页'),(4,'模板三','view3',0,1541007043,1541007043,'雀付优化模板-有登录页，注册页，支持手机浏览'),(5,'模板五','view5',0,1541007015,1541007015,'无首页-有登录页，注册页-自适应手机'),(6,'九州支付','view6',0,1541007031,1541007031,'九州支付,有登录页，不支持手机访问'),(8,'okpay-最新','view7',0,1552984915,1552984915,'只有登录注册页20190319更新'),(9,'HYIP模板','view8',0,1556695693,1556695693,'QQ1968984054原创模板'),(10,'模板9','view9',0,0,1564803363,'2019年8月新增'),(11,'模板10','view10',1,1648515818,1648515818,'贱贱2022年新模板');
/*!40000 ALTER TABLE `pay_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_tikuanconfig`
--

DROP TABLE IF EXISTS `pay_tikuanconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_tikuanconfig` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '商户编号',
  `tkzxmoney` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '单笔最小提款金额',
  `tkzdmoney` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '单笔最大提款金额',
  `dayzdmoney` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '当日提款最大总金额',
  `dayzdnum` int(11) NOT NULL DEFAULT '0' COMMENT '当日提款最大次数',
  `t1zt` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT 'T+1 ：1开启 0 关闭',
  `t0zt` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'T+0 ：1开启 0 关闭',
  `gmt0` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '购买T0',
  `tkzt` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '提款设置 1 开启 0 关闭',
  `tktype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '提款手续费类型 1 每笔 0 比例 ',
  `systemxz` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 系统规则 1 用户规则',
  `sxfrate` varchar(20) DEFAULT NULL COMMENT '单笔提款比例',
  `sxffixed` varchar(20) DEFAULT NULL COMMENT '单笔提款手续费',
  `issystem` tinyint(1) unsigned DEFAULT '0' COMMENT '平台规则 1 是 0 否',
  `allowstart` varchar(20) NOT NULL DEFAULT '0' COMMENT '提款允许开始时间',
  `allowend` varchar(20) NOT NULL DEFAULT '0' COMMENT '提款允许结束时间',
  `daycardzdmoney` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '单人单卡单日最高提现额',
  `auto_df_switch` tinyint(1) NOT NULL DEFAULT '0' COMMENT '自动代付开关',
  `auto_df_maxmoney` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '单笔代付最大金额限制',
  `auto_df_stime` varchar(20) NOT NULL DEFAULT '' COMMENT '自动代付开始时间',
  `auto_df_etime` varchar(20) NOT NULL DEFAULT '' COMMENT '自动代付结束时间',
  `auto_df_max_count` int(11) NOT NULL DEFAULT '0' COMMENT '商户每天自动代付笔数限制',
  `auto_df_max_sum` int(11) NOT NULL DEFAULT '0' COMMENT '商户每天自动代付最大总金额限制',
  `tk_charge_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '扣除手续费方式，0：从到账金额里扣，1：从商户余额里扣',
  PRIMARY KEY (`id`),
  UNIQUE KEY `IND_UID` (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_tikuanconfig`
--

LOCK TABLES `pay_tikuanconfig` WRITE;
/*!40000 ALTER TABLE `pay_tikuanconfig` DISABLE KEYS */;
INSERT INTO `pay_tikuanconfig` VALUES (28,505,1.00,1000000.00,50000000.00,100,0,0,200.00,1,1,0,'1','1',1,'00:00','00:01',1000000.00,1,50000.00,'00:00','23:59',0,0,1),(29,2,0.00,0.00,0.00,0,1,0,0.00,1,1,0,'','2',0,'0','0',0.00,0,0.00,'','',0,0,0),(30,180762223,500.00,50000.00,1000000.00,100,0,0,0.00,1,1,1,'1','5',0,'0','0',0.00,0,0.00,'','',0,0,1),(31,180751041,1.00,100.01,500.00,5,0,0,0.00,0,0,1,'0.1','',0,'0','0',0.00,0,0.00,'','',0,0,0),(32,180768736,100.00,50000.00,1100000.00,100,0,0,0.00,0,1,1,'','5',0,'0','0',0.00,0,0.00,'','',0,0,0),(33,4,0.00,0.00,0.00,0,0,0,0.00,0,0,1,'','',0,'0','0',0.00,0,0.00,'','',0,0,0),(34,31,0.00,0.00,0.00,0,1,0,0.00,0,0,1,'','',0,'0','0',0.00,0,0.00,'','',0,0,0),(35,34,1.00,100.00,0.00,0,0,0,0.00,0,0,1,'','',0,'0','0',0.00,0,0.00,'','',0,0,0),(36,48,0.00,0.00,0.00,0,0,0,0.00,0,0,0,NULL,NULL,0,'0','0',0.00,0,0.00,'','',0,0,0),(37,55,0.00,0.00,0.00,0,0,0,0.00,0,0,0,NULL,NULL,0,'0','0',0.00,0,0.00,'','',0,0,0);
/*!40000 ALTER TABLE `pay_tikuanconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_tikuanholiday`
--

DROP TABLE IF EXISTS `pay_tikuanholiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_tikuanholiday` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `datetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排除日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='排除节假日';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_tikuanholiday`
--

LOCK TABLES `pay_tikuanholiday` WRITE;
/*!40000 ALTER TABLE `pay_tikuanholiday` DISABLE KEYS */;
INSERT INTO `pay_tikuanholiday` VALUES (19,1562688000);
/*!40000 ALTER TABLE `pay_tikuanholiday` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_tikuanmoney`
--

DROP TABLE IF EXISTS `pay_tikuanmoney`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_tikuanmoney` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0' COMMENT '结算用户ID',
  `websiteid` int(11) NOT NULL DEFAULT '0',
  `payapiid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '结算通道ID',
  `t` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '结算方式: 1 T+1 ,0 T+0',
  `money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `datetype` varchar(2) NOT NULL,
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=691 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_tikuanmoney`
--

LOCK TABLES `pay_tikuanmoney` WRITE;
/*!40000 ALTER TABLE `pay_tikuanmoney` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_tikuanmoney` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_tikuantime`
--

DROP TABLE IF EXISTS `pay_tikuantime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_tikuantime` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `baiks` tinyint(2) unsigned DEFAULT '0' COMMENT '白天提款开始时间',
  `baijs` tinyint(2) unsigned DEFAULT '0' COMMENT '白天提款结束时间',
  `wanks` tinyint(2) unsigned DEFAULT '0' COMMENT '晚间提款开始时间',
  `wanjs` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='提款时间';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_tikuantime`
--

LOCK TABLES `pay_tikuantime` WRITE;
/*!40000 ALTER TABLE `pay_tikuantime` DISABLE KEYS */;
INSERT INTO `pay_tikuantime` VALUES (1,24,17,18,24);
/*!40000 ALTER TABLE `pay_tikuantime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_tklist`
--

DROP TABLE IF EXISTS `pay_tklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_tklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `bankname` varchar(300) NOT NULL,
  `bankzhiname` varchar(300) NOT NULL,
  `banknumber` varchar(300) NOT NULL,
  `bankfullname` varchar(300) NOT NULL,
  `sheng` varchar(300) NOT NULL,
  `shi` varchar(300) NOT NULL,
  `sqdatetime` datetime DEFAULT NULL,
  `cldatetime` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `tkmoney` decimal(15,2) NOT NULL DEFAULT '0.00',
  `sxfmoney` decimal(15,2) unsigned NOT NULL DEFAULT '0.00',
  `money` decimal(15,2) unsigned NOT NULL DEFAULT '0.00',
  `t` int(4) NOT NULL DEFAULT '1',
  `payapiid` int(11) NOT NULL DEFAULT '0',
  `memo` text COMMENT '备注',
  `tk_charge_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '扣除手续费方式，0：从到账金额里扣，1：从商户余额里扣',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_tklist`
--

LOCK TABLES `pay_tklist` WRITE;
/*!40000 ALTER TABLE `pay_tklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_tklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_updatelog`
--

DROP TABLE IF EXISTS `pay_updatelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_updatelog` (
  `version` varchar(20) NOT NULL DEFAULT '购买联系QQ9861262',
  `lastupdate` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_updatelog`
--

LOCK TABLES `pay_updatelog` WRITE;
/*!40000 ALTER TABLE `pay_updatelog` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_updatelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_user_channel_account`
--

DROP TABLE IF EXISTS `pay_user_channel_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_user_channel_account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `account_ids` varchar(255) NOT NULL DEFAULT '' COMMENT '子账号id',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否开启指定账号',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='用户指定指账号';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_user_channel_account`
--

LOCK TABLES `pay_user_channel_account` WRITE;
/*!40000 ALTER TABLE `pay_user_channel_account` DISABLE KEYS */;
INSERT INTO `pay_user_channel_account` VALUES (4,180762223,'2,50',0),(5,180751041,'16,17',1),(6,180768751,'',0),(7,6,'74',1),(8,62,'59,60,72',1),(9,200328822,'',0),(10,200795082,'177',1),(11,200368395,'168',1),(12,200829670,'187',1),(13,200993842,'',0);
/*!40000 ALTER TABLE `pay_user_channel_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_user_code`
--

DROP TABLE IF EXISTS `pay_user_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_user_code` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT '0' COMMENT '0找回密码',
  `code` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `ctime` int(11) DEFAULT NULL,
  `uptime` int(11) DEFAULT NULL COMMENT '更新时间',
  `endtime` int(11) DEFAULT NULL COMMENT '有效时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_user_code`
--

LOCK TABLES `pay_user_code` WRITE;
/*!40000 ALTER TABLE `pay_user_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_user_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_user_riskcontrol_config`
--

DROP TABLE IF EXISTS `pay_user_riskcontrol_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_user_riskcontrol_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `min_money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '单笔最小金额',
  `max_money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '单笔最大金额',
  `unit_all_money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '单位时间内交易总金额',
  `all_money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '当天交易总金额',
  `start_time` tinyint(10) unsigned NOT NULL DEFAULT '0' COMMENT '一天交易开始时间',
  `end_time` tinyint(10) unsigned NOT NULL DEFAULT '0' COMMENT '一天交易结束时间',
  `unit_number` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '单位时间内交易的总笔数',
  `is_system` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否平台规则',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态:1开通，0关闭',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `time_unit` char(1) NOT NULL DEFAULT 'i' COMMENT '限制的时间单位',
  `unit_interval` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '单位时间值',
  `domain` varchar(255) NOT NULL DEFAULT ' ' COMMENT '防封域名',
  `systemxz` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 系统规则 1 用户规则',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COMMENT='交易配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_user_riskcontrol_config`
--

LOCK TABLES `pay_user_riskcontrol_config` WRITE;
/*!40000 ALTER TABLE `pay_user_riskcontrol_config` DISABLE KEYS */;
INSERT INTO `pay_user_riskcontrol_config` VALUES (1,0,500.00,0.00,0.00,0.00,0,0,0,1,0,1543806443,0,'i',0,'',0),(2,180751041,0.00,10000.00,0.00,0.00,0,0,0,0,0,1533759190,1532768653,'s',0,'',1),(3,180768684,1.00,10000.00,0.00,299972.00,0,0,0,0,1,1532846143,1532774264,'s',0,'',1),(4,180762223,10.00,5000.00,0.00,0.00,0,0,0,0,0,1536964058,1532774447,'s',0,'',0);
/*!40000 ALTER TABLE `pay_user_riskcontrol_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_userrate`
--

DROP TABLE IF EXISTS `pay_userrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_userrate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `payapiid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '通道ID',
  `feilv` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT '运营费率',
  `fengding` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT '封顶费率',
  `t0feilv` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT 'T0运营费率',
  `t0fengding` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT 'T0封顶费率',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商户通道费率';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_userrate`
--

LOCK TABLES `pay_userrate` WRITE;
/*!40000 ALTER TABLE `pay_userrate` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_userrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_version`
--

DROP TABLE IF EXISTS `pay_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_version` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL DEFAULT '0' COMMENT '版本',
  `author` varchar(255) NOT NULL DEFAULT ' ' COMMENT '作者',
  `save_time` varchar(255) NOT NULL DEFAULT '0000-00-00' COMMENT '修改时间,格式YYYY-mm-dd',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='数据库版本表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_version`
--

LOCK TABLES `pay_version` WRITE;
/*!40000 ALTER TABLE `pay_version` DISABLE KEYS */;
INSERT INTO `pay_version` VALUES (1,'5.5','qq9861262','2018-4-8'),(2,'5.6','qq9861262','2018/9/02 17:45:33'),(3,'6.0.4','MTk2ODk4NDA1NA==','2019/07/20');
/*!40000 ALTER TABLE `pay_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_websiteconfig`
--

DROP TABLE IF EXISTS `pay_websiteconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_websiteconfig` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `websitename` varchar(300) DEFAULT NULL COMMENT '网站名称',
  `domain` varchar(300) DEFAULT NULL COMMENT '网址',
  `email` varchar(100) DEFAULT NULL,
  `tel` varchar(30) DEFAULT NULL,
  `qq` varchar(30) DEFAULT NULL,
  `directory` varchar(100) DEFAULT NULL COMMENT '后台目录名称',
  `icp` varchar(100) DEFAULT NULL,
  `tongji` varchar(1000) DEFAULT NULL COMMENT '统计',
  `login` varchar(100) DEFAULT NULL COMMENT '登录地址',
  `payingservice` tinyint(1) unsigned DEFAULT '0' COMMENT '商户代付 1 开启 0 关闭',
  `authorized` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '商户认证 1 开启 0 关闭',
  `invitecode` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '邀请码注册',
  `company` varchar(200) DEFAULT NULL COMMENT '公司名称',
  `serverkey` varchar(50) DEFAULT NULL COMMENT '授权服务key修改联系QQ1968984054',
  `withdraw` tinyint(1) DEFAULT '0' COMMENT '提现通知：0关闭，1开启',
  `login_warning_num` tinyint(3) unsigned NOT NULL DEFAULT '3' COMMENT '前台可以错误登录次数',
  `login_ip` varchar(1000) NOT NULL DEFAULT ' ' COMMENT '登录IP',
  `is_repeat_order` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否允许重复订单:1是，0否',
  `google_auth` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开启谷歌身份验证登录',
  `df_api` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开启代付API',
  `logo` varchar(255) NOT NULL DEFAULT ' ' COMMENT '公司logo',
  `random_mchno` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开启随机商户号',
  `register_need_activate` tinyint(1) NOT NULL DEFAULT '0' COMMENT '用户注册是否需激活',
  `admin_alone_login` tinyint(1) NOT NULL DEFAULT '0' COMMENT '管理员是否只允许同时一次登录',
  `max_auth_error_times` int(10) NOT NULL DEFAULT '5' COMMENT '验证错误最大次数',
  `auth_error_ban_time` int(10) NOT NULL DEFAULT '10' COMMENT '验证错误超限冻结时间（分钟）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_websiteconfig`
--

LOCK TABLES `pay_websiteconfig` WRITE;
/*!40000 ALTER TABLE `pay_websiteconfig` DISABLE KEYS */;
INSERT INTO `pay_websiteconfig` VALUES (1,'daifuxt','daifu.fk08.cn','kefu@qq.com','1888888888','22222222','admin','闽ICP备17031751号-1','','taoke',1,0,0,'锐驰智联科技有限公司','0d6de302cbc615de3b09463acea87662',1,3,' ',0,0,1,'Uploads/logo/5d41cdd0bcf75.png',0,0,0,999,3464);
/*!40000 ALTER TABLE `pay_websiteconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_wsry`
--

DROP TABLE IF EXISTS `pay_wsry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_wsry` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `shid` varchar(255) DEFAULT NULL,
  `ordernotwo` varchar(255) DEFAULT NULL,
  `money` double(10,2) DEFAULT '0.00',
  `sjmoney` double(10,2) DEFAULT '0.00',
  `sxf` double(10,2) DEFAULT '0.00',
  `orderno` varchar(255) DEFAULT NULL,
  `ordernum` varchar(10) DEFAULT NULL,
  `paytype` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `gettime` datetime DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_wsry`
--

LOCK TABLES `pay_wsry` WRITE;
/*!40000 ALTER TABLE `pay_wsry` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_wsry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_wttklist`
--

DROP TABLE IF EXISTS `pay_wttklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_wttklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `bankname` varchar(300) NOT NULL,
  `bankzhiname` varchar(300) NOT NULL,
  `banknumber` varchar(300) NOT NULL,
  `bankfullname` varchar(300) NOT NULL,
  `sheng` varchar(300) NOT NULL,
  `shi` varchar(300) NOT NULL,
  `sqdatetime` datetime DEFAULT NULL,
  `cldatetime` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `tkmoney` decimal(15,2) NOT NULL DEFAULT '0.00',
  `sxfmoney` decimal(15,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '手续费',
  `money` decimal(15,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '实际到账',
  `t` int(4) NOT NULL DEFAULT '1',
  `payapiid` int(11) NOT NULL DEFAULT '0',
  `memo` text COMMENT '备注',
  `additional` varchar(1000) NOT NULL DEFAULT ' ' COMMENT '额外的参数',
  `code` varchar(64) NOT NULL DEFAULT ' ' COMMENT '代码控制器名称',
  `df_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '代付通道id',
  `df_name` varchar(64) NOT NULL DEFAULT ' ' COMMENT '代付名称',
  `orderid` varchar(100) NOT NULL DEFAULT ' ' COMMENT '订单id',
  `cost` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT '成本',
  `cost_rate` decimal(10,4) unsigned NOT NULL DEFAULT '0.0000' COMMENT '成本费率',
  `rate_type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '费率类型：按单笔收费0，按比例收费：1',
  `extends` text COMMENT '扩展数据',
  `out_trade_no` varchar(30) DEFAULT '' COMMENT '下游订单号',
  `df_api_id` int(11) DEFAULT '0' COMMENT '代付API申请ID',
  `auto_submit_try` int(10) NOT NULL DEFAULT '0' COMMENT '自动代付尝试提交次数',
  `is_auto` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否自动提交',
  `last_submit_time` int(11) NOT NULL DEFAULT '0' COMMENT '最后提交时间',
  `df_lock` tinyint(1) NOT NULL DEFAULT '0' COMMENT '代付锁，防止重复提交',
  `auto_query_num` int(10) NOT NULL DEFAULT '0' COMMENT '自动查询次数',
  `channel_mch_id` varchar(50) NOT NULL DEFAULT '' COMMENT '通道商户号',
  `df_charge_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '代付API扣除手续费方式，0：从到账金额里扣，1：从商户余额里扣',
  PRIMARY KEY (`id`),
  KEY `code` (`code`),
  KEY `df_id` (`df_id`),
  KEY `orderid` (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_wttklist`
--

LOCK TABLES `pay_wttklist` WRITE;
/*!40000 ALTER TABLE `pay_wttklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_wttklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'daifu_fk08_cn'
--

--
-- Dumping routines for database 'daifu_fk08_cn'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-19 14:25:23
